#ifndef STEPPER_H
#define STEPPER_H

#include "stm32f4xx_hal.h"

// Direction definition
typedef enum
{
    STEPPER_DIR_CW = 0,
    STEPPER_DIR_CCW = 1
} StepperDirection;

// Stepper structure (configurable GPIO)
typedef struct
{
    GPIO_TypeDef* PUL_Port;
    uint16_t      PUL_PinNum;

    GPIO_TypeDef* DIR_Port;
    uint16_t      DIR_PinNum;

    GPIO_TypeDef* ENA_Port;
    uint16_t      ENA_PinNum;

} Stepper_HandleTypeDef;

// Function declarations
void delay_us(uint32_t us);
void Stepper_Enable(Stepper_HandleTypeDef *stepper);
void Stepper_Disable(Stepper_HandleTypeDef *stepper);
void Stepper_SetDirection(Stepper_HandleTypeDef *stepper, StepperDirection dir);
void Stepper_Step(Stepper_HandleTypeDef *stepper);
void Stepper_MoveSteps(Stepper_HandleTypeDef *stepper, uint32_t steps, uint32_t delay_us);

#endif
