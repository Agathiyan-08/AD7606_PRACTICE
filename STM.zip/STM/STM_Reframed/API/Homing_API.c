#include "Homing_API.h"

HomingStatus Axis_Home(Axis_HandleTypeDef *axis)
{
    uint32_t step_count = 0;

    /* Enable motor */
    Stepper_Enable(axis->stepper);

    /* Move towards limit switch (BACKWARD) */
    Stepper_SetDirection(axis->stepper, STEPPER_DIR_CW);

    while(!LimitSwitch_ReadDebounced())
    {
//        Stepper_MoveSteps(axis->stepper, 1, HOMING_STEP_DELAY_US);
    	Stepper_Step(axis->stepper);
        delay_us(5);
        step_count++;

        if(step_count > MAX_HOMING_STEPS)
        {
            return HOMING_TIMEOUT;
        }
    }

    /* Switch hit */

    /* Move forward for clearance */
    Stepper_SetDirection(axis->stepper, STEPPER_DIR_CCW);

    Stepper_MoveSteps(axis->stepper,
                      HOMING_CLEARANCE_STEPS,
                      HOMING_STEP_DELAY_US);

    /* Set position as zero */
    axis->position_mm = 0.0f;

    return HOMING_OK;
}
