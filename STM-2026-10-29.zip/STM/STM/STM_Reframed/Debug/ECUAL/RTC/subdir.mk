################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ECUAL/RTC/Ds3231_Driver.c 

OBJS += \
./ECUAL/RTC/Ds3231_Driver.o 

C_DEPS += \
./ECUAL/RTC/Ds3231_Driver.d 


# Each subdirectory must supply rules for building sources it contributes
ECUAL/RTC/%.o ECUAL/RTC/%.su ECUAL/RTC/%.cyclo: ../ECUAL/RTC/%.c ECUAL/RTC/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-ECUAL-2f-RTC

clean-ECUAL-2f-RTC:
	-$(RM) ./ECUAL/RTC/Ds3231_Driver.cyclo ./ECUAL/RTC/Ds3231_Driver.d ./ECUAL/RTC/Ds3231_Driver.o ./ECUAL/RTC/Ds3231_Driver.su

.PHONY: clean-ECUAL-2f-RTC

