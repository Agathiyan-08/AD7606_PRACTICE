/*
 * Cyclic_test_API.h
 *
 *  Created on: Mar 16, 2026
 *      Author: thara
 */

#ifndef CYCLIC_TEST_API_H_
#define CYCLIC_TEST_API_H_


#include <stdbool.h>
#include <stdint.h>
#include "../../ECUAL/Linear_Axis/linear_axis.h"

typedef struct
{
    float null_machine_mm;

    float stroke_range_mm;
    float null_voltage_mv;
    float sensitivity_mv_v_mm;
    float excitation_voltage_v;

    float required_accuracy_percent;

    float null_displacement_mm;
    float max_displacement_mm;

    uint32_t cycle_count;

} CyclicTestParams_t;

typedef enum
{
    CYCLIC_TEST_OK = 0,
    CYCLIC_TEST_ABORTED,
    CYCLIC_TEST_ERROR

} CyclicTestResult;

CyclicTestResult Cyclic_Test_Run(LinearAxis_t *axis, CyclicTestParams_t *params);




#endif /* CYCLIC_TEST_API_H_ */
