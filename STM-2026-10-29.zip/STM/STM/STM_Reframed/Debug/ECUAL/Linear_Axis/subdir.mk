################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ECUAL/Linear_Axis/linear_axis_api.c 

OBJS += \
./ECUAL/Linear_Axis/linear_axis_api.o 

C_DEPS += \
./ECUAL/Linear_Axis/linear_axis_api.d 


# Each subdirectory must supply rules for building sources it contributes
ECUAL/Linear_Axis/%.o ECUAL/Linear_Axis/%.su ECUAL/Linear_Axis/%.cyclo: ../ECUAL/Linear_Axis/%.c ECUAL/Linear_Axis/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-ECUAL-2f-Linear_Axis

clean-ECUAL-2f-Linear_Axis:
	-$(RM) ./ECUAL/Linear_Axis/linear_axis_api.cyclo ./ECUAL/Linear_Axis/linear_axis_api.d ./ECUAL/Linear_Axis/linear_axis_api.o ./ECUAL/Linear_Axis/linear_axis_api.su

.PHONY: clean-ECUAL-2f-Linear_Axis

