
#include "stepper_config.h"

/* Stepper motor instance */
Stepper_HandleTypeDef hstepper1;
/*
    Configure the pins for the stepper motor
    Change these pins according to your board
*/

void Stepper_Config_Init(void)
{
    /* Pulse pin */
    hstepper1.PUL_Port = GPIOB;
    hstepper1.PUL_PinNum = GPIO_PIN_5;

    /* Direction pin */
    hstepper1.DIR_Port = GPIOB;
    hstepper1.DIR_PinNum = GPIO_PIN_7;

    /* Enable pin */
    hstepper1.ENA_Port = GPIOB;
    hstepper1.ENA_PinNum = GPIO_PIN_6;



}
