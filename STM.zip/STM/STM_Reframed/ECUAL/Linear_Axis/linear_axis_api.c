/*
 * linear_axis_api.c
 *
 *  Created on: Mar 6, 2026
 *      Author: Admin
 */
#include "linear_axis.h"


/* -------- Initialization -------- */

void Axis_Init(LinearAxis_t *axis,AccelStepper_Handle_t *stepper)
{
    axis->stepper = stepper;

    axis->soft_limit_min_mm = 0.0f;
    axis->soft_limit_max_mm = 0.0f;

    axis->home_pos_mm = 0.0f;

    axis->is_homed = false;
}


/* -------- Configuration -------- */

HAL_StatusTypeDef Axis_SetSoftLimits(LinearAxis_t *axis,float min_mm,float max_mm)
{
    if (max_mm <= min_mm)
        return HAL_ERROR;

    axis->soft_limit_min_mm = min_mm;
    axis->soft_limit_max_mm = max_mm;

    return HAL_OK;
}

void Axis_SetHomePosition(LinearAxis_t *axis, float home_mm)
{
    axis->home_pos_mm = home_mm;
}

/* -------- Motion Commands -------- */

HAL_StatusTypeDef Axis_MoveAbsolute(LinearAxis_t *axis, float target_mm)
{
    if (!axis->is_homed)
        return HAL_ERROR;

    if (target_mm < axis->soft_limit_min_mm ||
        target_mm > axis->soft_limit_max_mm)
        return HAL_ERROR;

    int32_t target_steps = MM_TO_STEPS(target_mm);

    AccelStepper_MoveTo(axis->stepper, target_steps);

    return HAL_OK;
}

HAL_StatusTypeDef Axis_MoveRelative(LinearAxis_t *axis, float delta_mm)
{
    float current_mm = Axis_GetPosition_mm(axis);

    float target_mm = current_mm + delta_mm;

    return Axis_MoveAbsolute(axis, target_mm);
}

HAL_StatusTypeDef Axis_MoveToHome(LinearAxis_t *axis)
{
    return Axis_MoveAbsolute(axis, axis->home_pos_mm);
}

HAL_StatusTypeDef Axis_Stop(LinearAxis_t *axis)
{
    AccelStepper_StopSmooth(axis->stepper);

    return HAL_OK;
}

HAL_StatusTypeDef Axis_EmergencyStop(LinearAxis_t *axis)
{
    AccelStepper_Stop(axis->stepper);

    return HAL_OK;
}

/* -------- Status / Query -------- */

float Axis_GetPosition_mm(LinearAxis_t *axis)
{
    int32_t steps;

    steps = AccelStepper_CurrentPosition(axis->stepper);

    return STEPS_TO_MM(steps);
}

float Axis_GetTarget_mm(LinearAxis_t *axis)
{
    int32_t steps;

    steps = AccelStepper_TargetPosition(axis->stepper);

    return STEPS_TO_MM(steps);
}


bool Axis_IsHomed(LinearAxis_t *axis)
{
    return axis->is_homed;
}


bool Axis_IsMoving(LinearAxis_t *axis)
{
    return AccelStepper_IsRunning(axis->stepper);
}
