#include "stepper_motor_API.h"
#include  "../../util/Util.h"
// Simple delay in microseconds (uses DWT)
void delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (HAL_RCC_GetHCLKFreq() / 1000000);

    while ((DWT->CYCCNT - start) < ticks);
}

// Enable motor (ENA LOW for most drivers, adjust if needed)
void Stepper_Enable(Stepper_HandleTypeDef *stepper)
{
    HAL_GPIO_WritePin(stepper->ENA_Port, stepper->ENA_PinNum, GPIO_PIN_RESET);
}

// Disable motor
void Stepper_Disable(Stepper_HandleTypeDef *stepper)
{
    HAL_GPIO_WritePin(stepper->ENA_Port, stepper->ENA_PinNum, GPIO_PIN_SET);
}

// Set direction
void Stepper_SetDirection(Stepper_HandleTypeDef *stepper, StepperDirection dir)
{
    if (dir == STEPPER_DIR_CW)
    {
        HAL_GPIO_WritePin(stepper->DIR_Port, stepper->DIR_PinNum, GPIO_PIN_SET);
    }
    else
    {
        HAL_GPIO_WritePin(stepper->DIR_Port, stepper->DIR_PinNum, GPIO_PIN_RESET);
    }
}

// Single step pulse
void Stepper_Step(Stepper_HandleTypeDef *stepper)
{
    stepper->PUL_Port->BSRR = stepper->PUL_PinNum;          // HIGH
    DELAY_US(5U);
    stepper->PUL_Port->BSRR = stepper->PUL_PinNum << 16U;
    DELAY_US(5U);
}

// Move N steps
/*currently this is completely blocking code use this wise,
 *this api is add because to overcome the repeated useage for stepper_step function */

void Stepper_MoveSteps(Stepper_HandleTypeDef *stepper, uint32_t steps, uint32_t delay_us_val)
{
    for (uint32_t i = 0; i < steps; i++)
    {
        Stepper_Step(stepper);
        delay_us(delay_us_val);  // speed control
    }
}
