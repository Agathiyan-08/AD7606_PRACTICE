/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
float Get_LVDT_null(void);
bool Get_LVDT_boll(void);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SPI2_CS_Pin GPIO_PIN_3
#define SPI2_CS_GPIO_Port GPIOC
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define ADC_OS0_Pin GPIO_PIN_6
#define ADC_OS0_GPIO_Port GPIOA
#define ADC_OS1_Pin GPIO_PIN_7
#define ADC_OS1_GPIO_Port GPIOA
#define ADC_Busy_Pin GPIO_PIN_4
#define ADC_Busy_GPIO_Port GPIOC
#define R3_Pin GPIO_PIN_5
#define R3_GPIO_Port GPIOC
#define C4_Pin GPIO_PIN_1
#define C4_GPIO_Port GPIOB
#define C3_Pin GPIO_PIN_2
#define C3_GPIO_Port GPIOB
#define C2_Pin GPIO_PIN_12
#define C2_GPIO_Port GPIOB
#define ADC_Range_Pin GPIO_PIN_13
#define ADC_Range_GPIO_Port GPIOB
#define ADC_CVB_Pin GPIO_PIN_14
#define ADC_CVB_GPIO_Port GPIOB
#define Limit_Pin_Pin GPIO_PIN_15
#define Limit_Pin_GPIO_Port GPIOB
#define R2_Pin GPIO_PIN_6
#define R2_GPIO_Port GPIOC
#define ADC_CS_Pin GPIO_PIN_7
#define ADC_CS_GPIO_Port GPIOC
#define R1_Pin GPIO_PIN_8
#define R1_GPIO_Port GPIOC
#define ADC_OS2_Pin GPIO_PIN_9
#define ADC_OS2_GPIO_Port GPIOC
#define ADC_RST_Pin GPIO_PIN_8
#define ADC_RST_GPIO_Port GPIOA
#define C1_Pin GPIO_PIN_11
#define C1_GPIO_Port GPIOA
#define R4_Pin GPIO_PIN_12
#define R4_GPIO_Port GPIOA
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB
#define ADC_CVA_Pin GPIO_PIN_4
#define ADC_CVA_GPIO_Port GPIOB
#define PUL_Pin GPIO_PIN_5
#define PUL_GPIO_Port GPIOB
#define ENA_Pin GPIO_PIN_6
#define ENA_GPIO_Port GPIOB
#define DIR_Pin GPIO_PIN_7
#define DIR_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
