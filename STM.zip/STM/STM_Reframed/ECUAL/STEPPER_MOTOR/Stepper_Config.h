/*
 * Stepper_Config.h
 *
 *  Created on: Mar 5, 2026
 *      Author: Admin
 */

#ifndef STEPPER_MOTOR_STEPPER_CONFIG_H_
#define STEPPER_MOTOR_STEPPER_CONFIG_H_

#include "stepper_motor_API.h"

/* Exported stepper motor handle */
extern Stepper_HandleTypeDef hstepper1;

/* Configuration initialization */
void Stepper_Config_Init(void);

#endif /* STEPPER_MOTOR_STEPPER_CONFIG_H_ */
