
#include "main.h"

/* SPI handle */
SPI_HandleTypeDef hspi3;

/* Debug variables: inspect these in STM32CubeIDE */
volatile HAL_StatusTypeDef adcStatus = HAL_ERROR;
volatile HAL_StatusTypeDef spiStatus = HAL_ERROR;

volatile uint32_t adcSuccessCount = 0;
volatile uint32_t adcErrorCount = 0;
volatile uint32_t busyTimeoutCount = 0;
volatile uint32_t spiErrorCount = 0;

volatile int16_t adcRaw[4] = {0};
volatile float adcVoltage[4] = {0.0f};

/* AD7606 configuration */
#define AD7606_BUSY_TIMEOUT_MS  50U
#define AD7606_SPI_TIMEOUT_MS   100U
#define AD7606_CHANNEL_COUNT    4U
#define AD7606_INPUT_RANGE_V    5.0f

/* Function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI3_Init(void);
void Error_Handler(void);

static HAL_StatusTypeDef AD7606_WaitBusy(GPIO_PinState state);
static void AD7606_Init_Test(void);
static HAL_StatusTypeDef AD7606_ReadDOUTA(int16_t *raw);

/* Main ----------------------------------------------------------------------*/
int main(void)
{
    HAL_Init();

    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI3_Init();

    AD7606_Init_Test();

    while (1)
    {
        adcStatus = AD7606_ReadDOUTA((int16_t *)adcRaw);

        if (adcStatus == HAL_OK)
        {
            for (uint32_t i = 0; i < AD7606_CHANNEL_COUNT; i++)
            {
                /*
                 * Assumes bipolar two's-complement output
                 * and the AD7606 +/-5 V input range.
                 */
                adcVoltage[i] =
                    ((float)adcRaw[i] * AD7606_INPUT_RANGE_V)
                    / 32768.0f;
            }

            adcSuccessCount++;
        }
        else
        {
            adcErrorCount++;
        }

        HAL_Delay(100);
    }
}

/* Wait for BUSY to reach the requested state -------------------------------*/
static HAL_StatusTypeDef AD7606_WaitBusy(GPIO_PinState state)
{
    uint32_t startTick = HAL_GetTick();

    while (HAL_GPIO_ReadPin(ADC_Busy_GPIO_Port,
                            ADC_Busy_Pin) != state)
    {
        if ((HAL_GetTick() - startTick) >=
            AD7606_BUSY_TIMEOUT_MS)
        {
            busyTimeoutCount++;
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/* Initialize AD7606 control pins -------------------------------------------*/
static void AD7606_Init_Test(void)
{
    /* Keep serial output disabled initially */
    HAL_GPIO_WritePin(ADC_CS_GPIO_Port,
                      ADC_CS_Pin, GPIO_PIN_SET);

    /* Select +/-5 V range: verify against your board's RANGE polarity */
    HAL_GPIO_WritePin(ADC_Range_GPIO_Port,
                      ADC_Range_Pin, GPIO_PIN_RESET);

    /* Disable oversampling */
    HAL_GPIO_WritePin(ADC_OS0_GPIO_Port,
                      ADC_OS0_Pin, GPIO_PIN_RESET);

    HAL_GPIO_WritePin(ADC_OS1_GPIO_Port,
                      ADC_OS1_Pin, GPIO_PIN_RESET);

    HAL_GPIO_WritePin(ADC_OS2_GPIO_Port,
                      ADC_OS2_Pin, GPIO_PIN_RESET);

    /* Conversion-start signals idle low */
    HAL_GPIO_WritePin(ADC_CVA_GPIO_Port,
                      ADC_CVA_Pin, GPIO_PIN_RESET);

    HAL_GPIO_WritePin(ADC_CVB_GPIO_Port,
                      ADC_CVB_Pin, GPIO_PIN_RESET);

    /* RESET is active high */
    HAL_GPIO_WritePin(ADC_RST_GPIO_Port,
                      ADC_RST_Pin, GPIO_PIN_RESET);

    HAL_Delay(1);

    HAL_GPIO_WritePin(ADC_RST_GPIO_Port,
                      ADC_RST_Pin, GPIO_PIN_SET);

    HAL_Delay(1);

    HAL_GPIO_WritePin(ADC_RST_GPIO_Port,
                      ADC_RST_Pin, GPIO_PIN_RESET);

    HAL_Delay(1);
}

/* Trigger conversion and read four words from DOUTA ------------------------*/
static HAL_StatusTypeDef AD7606_ReadDOUTA(int16_t *raw)
{
    uint8_t rx[AD7606_CHANNEL_COUNT * 2U] = {0};

    if (raw == NULL)
    {
        return HAL_ERROR;
    }

    /* Ensure the previous conversion has finished */
    if (AD7606_WaitBusy(GPIO_PIN_RESET) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }

    /*
     * Start conversion using the rising edges of CONVST_A and CONVST_B.
     * The 1 ms pulse is intentionally slow for this diagnostic test.
     */
    HAL_GPIO_WritePin(ADC_CVA_GPIO_Port,
                      ADC_CVA_Pin, GPIO_PIN_SET);

    HAL_GPIO_WritePin(ADC_CVB_GPIO_Port,
                      ADC_CVB_Pin, GPIO_PIN_SET);

    /* BUSY should assert when conversion starts */
    if (AD7606_WaitBusy(GPIO_PIN_SET) != HAL_OK)
    {
        HAL_GPIO_WritePin(ADC_CVA_GPIO_Port,
                          ADC_CVA_Pin, GPIO_PIN_RESET);

        HAL_GPIO_WritePin(ADC_CVB_GPIO_Port,
                          ADC_CVB_Pin, GPIO_PIN_RESET);

        return HAL_TIMEOUT;
    }

    HAL_GPIO_WritePin(ADC_CVA_GPIO_Port,
                      ADC_CVA_Pin, GPIO_PIN_RESET);

    HAL_GPIO_WritePin(ADC_CVB_GPIO_Port,
                      ADC_CVB_Pin, GPIO_PIN_RESET);

    /* Wait until conversion completes */
    if (AD7606_WaitBusy(GPIO_PIN_RESET) != HAL_OK)
    {
        return HAL_TIMEOUT;
    }

    /* Read data from the serial output */
    HAL_GPIO_WritePin(ADC_CS_GPIO_Port,
                      ADC_CS_Pin, GPIO_PIN_RESET);

    spiStatus = HAL_SPI_Receive(&hspi3,
                                rx,
                                sizeof(rx),
                                AD7606_SPI_TIMEOUT_MS);

    HAL_GPIO_WritePin(ADC_CS_GPIO_Port,
                      ADC_CS_Pin, GPIO_PIN_SET);

    if (spiStatus != HAL_OK)
    {
        spiErrorCount++;
        return spiStatus;
    }

    /* Combine each pair of bytes into a signed 16-bit sample */
    for (uint32_t i = 0; i < AD7606_CHANNEL_COUNT; i++)
    {
        uint16_t value =
            ((uint16_t)rx[2U * i] << 8) |
            (uint16_t)rx[(2U * i) + 1U];

        raw[i] = (int16_t)value;
    }

    return HAL_OK;
}

/* System clock: HSI at 16 MHz -----------------------------------------------*/
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();

    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType =
        RCC_CLOCKTYPE_SYSCLK |
        RCC_CLOCKTYPE_HCLK |
        RCC_CLOCKTYPE_PCLK1 |
        RCC_CLOCKTYPE_PCLK2;

    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct,
                            FLASH_LATENCY_0) != HAL_OK)
    {
        Error_Handler();
    }
}

/* SPI3: PC10 = SCK, PC11 = MISO --------------------------------------------*/
static void MX_SPI3_Init(void)
{
    hspi3.Instance = SPI3;
    hspi3.Init.Mode = SPI_MODE_MASTER;
    hspi3.Init.Direction = SPI_DIRECTION_2LINES_RXONLY;
    hspi3.Init.DataSize = SPI_DATASIZE_8BIT;
    hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;
    hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
    hspi3.Init.NSS = SPI_NSS_SOFT;
    hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
    hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
    hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
    hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    hspi3.Init.CRCPolynomial = 10;

    if (HAL_SPI_Init(&hspi3) != HAL_OK)
    {
        Error_Handler();
    }
}

/* GPIO initialization: preserve the supplied pin assignments ---------------*/
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* Set output levels before configuring the pins */
    HAL_GPIO_WritePin(GPIOA,
                      ADC_OS0_Pin |
                      ADC_OS1_Pin |
                      ADC_RST_Pin,
                      GPIO_PIN_RESET);

    HAL_GPIO_WritePin(GPIOB,
                      ADC_Range_Pin |
                      ADC_CVB_Pin |
                      ADC_CVA_Pin,
                      GPIO_PIN_RESET);

    HAL_GPIO_WritePin(GPIOC,
                      ADC_CS_Pin |
                      ADC_OS2_Pin,
                      GPIO_PIN_SET);

    /* PA6 = OS0, PA7 = OS1, PA8 = RESET */
    GPIO_InitStruct.Pin =
        ADC_OS0_Pin | ADC_OS1_Pin | ADC_RST_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* PB4 = CONVST_A, PB13 = RANGE, PB14 = CONVST_B */
    GPIO_InitStruct.Pin =
        ADC_Range_Pin | ADC_CVB_Pin | ADC_CVA_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* PC7 = CS, PC9 = OS2 */
    GPIO_InitStruct.Pin = ADC_CS_Pin | ADC_OS2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* PC4 = BUSY */
    GPIO_InitStruct.Pin = ADC_Busy_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(ADC_Busy_GPIO_Port, &GPIO_InitStruct);
}

/* Error handler -------------------------------------------------------------*/
void Error_Handler(void)
{
    __disable_irq();

    while (1)
    {
        /* Inspect the call stack when debugging */
    }
}
