/*
 * Random_Test_API.c
 *
 *  Created on: Mar 12, 2026
 *      Author: Admin
 */

#include "Random_Test_API.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

//include the AD7606
#include "../ECUAL/AD7606/ad7606.h"


/* ---- External keypad state & map (from your KEYPAD module) ---- */
extern uint8_t KeyStates[16];
extern uint8_t prevKeyStates[16];

#ifndef ROWS
#define ROWS 4
#endif
#ifndef COLS
#define COLS 4
#endif
extern const char KeyMap[ROWS][COLS];

/* ---- LCD instance ---- */
#define LCD I2C_LCD_1

/* ---- Axis limits (machine coordinates) ---- */
#define AXIS_MIN_MM      (0.0f)
#define AXIS_MAX_MM      (500.0f)
#define LOOP_SLEEP_MS    (5)

/* -------------------- Utilities -------------------- */

static inline float clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static inline char key_from_index(int i)
{
    int row = i / COLS;
    int col = i % COLS;
    return KeyMap[row][col];
}

// One rising-edge key; returns 0 if none
static char keypad_poll_edge(void)
{
    char pressed = 0;
    KEYPAD_Scan(0);
    for (int i = 0; i < 16; i++) {
        if (KeyStates[i] == KEY_PRESSED && prevKeyStates[i] == KEY_RELEASED) {
            HAL_Delay(20); // debounce
            KEYPAD_Scan(0);
            if (KeyStates[i] == KEY_PRESSED) {
                pressed = key_from_index(i);
            }
        }
        prevKeyStates[i] = KeyStates[i];
    }
    return pressed;
}

static void lcd_two_lines(const char* l1, const char* l2)
{
    I2C_LCD_Clear(LCD);
    I2C_LCD_SetCursor(LCD, 0, 0);
    I2C_LCD_WriteString(LCD, (char*)l1);
    I2C_LCD_SetCursor(LCD, 0, 1);
    I2C_LCD_WriteString(LCD, (char*)l2);
}


/* Read all ADC channels and convert to voltage.
   Returns true when acquisition succeeds. */
static bool random_test_read_voltage(float *voltage)
{
    int16_t adc_raw[RAW_DATA_SIZE];
    float adc_voltage[RAW_DATA_SIZE];

    if (voltage == NULL)
    {
        return false;
    }

    if (AD7606_ADC(adc_raw) != HAL_OK)
    {
        return false;
    }

    Data_Conv(adc_voltage, adc_raw);

    /* Initial assumption: LVDT output is connected to CH1 */
    *voltage = adc_voltage[0];

    return true;
}

/* Display machine position and measured voltage. */
static void random_test_show_measurement(float position_mm)
{
    char line1[17];
    char line2[17];
    float voltage = 0.0f;

    if (!random_test_read_voltage(&voltage))
    {
        snprintf(line1, sizeof(line1), "Pos:%7.2fmm",
                 position_mm);

        lcd_two_lines(line1, "ADC READ ERROR");
        return;
    }

    snprintf(line1, sizeof(line1), "Pos:%7.2fmm",
             position_mm);

    snprintf(line2, sizeof(line2), "CH1:%+6.3f V",
             (double)voltage);

    lcd_two_lines(line1, line2);
}


static bool parse_float(const char* s, float *out)
{
    if (!s) return false;
    while (*s == ' ') s++;
    if (*s == '\0') return false;
    char *endp = NULL;
    float v = strtof(s, &endp);
    if (endp == s) return false;
    *out = v;
    return true;
}

/* Generic numeric prompt using KEYPAD_Input_Get()
 * - title: first line prompt (<=16 chars recommended)
 * - unit:  optional suffix shown on accept (not typed)
 * - out:   parsed float on success
 * Returns: true on success, false on cancel (empty input then E)
 */
static bool prompt_float(const char* title, const char* unit, float *out)
{
    I2C_LCD_Clear(LCD);
    I2C_LCD_SetCursor(LCD, 0, 0);
    I2C_LCD_WriteString(LCD, (char*)title);
    I2C_LCD_SetCursor(LCD, 0, 1);
    I2C_LCD_WriteString(LCD, "Type.. E=OK C=Clr");

    while (1) {
        char *s = KEYPAD_Input_Get();
        if (s) {
            if (s[0] == '\0') {
                return false; // treat as cancel/back
            }
            float v = 0.0f;
            if (parse_float(s, &v)) {
                *out = v;
                char line1[17];
                snprintf(line1, sizeof(line1), "Set: %7.3f%s", v, (unit?unit:""));
                lcd_two_lines(line1, "OK");
                HAL_Delay(500);
                return true;
            } else {
                lcd_two_lines("Invalid number", "Try again...");
                HAL_Delay(700);
                I2C_LCD_Clear(LCD);
                I2C_LCD_SetCursor(LCD, 0, 0);
                I2C_LCD_WriteString(LCD, (char*)title);
                I2C_LCD_SetCursor(LCD, 0, 1);
                I2C_LCD_WriteString(LCD, "Type.. E=OK C=Clr");
            }
        }
        HAL_Delay(LOOP_SLEEP_MS);
    }
}

/* Wait-to-target helper: calls AccelStepper_Run() in a loop.
 * Shows spinner + live position on LCD line2.
 */
static void wait_to_target_with_lcd(LinearAxis_t *axis, const char *heading)
{
    static const char spin[4] = {'|','/','-','\\'};
    int si = 0;

    char l1[17];
    snprintf(l1, sizeof(l1), "%.16s", heading);
    I2C_LCD_Clear(LCD);
    I2C_LCD_SetCursor(LCD, 0, 0);
    I2C_LCD_WriteString(LCD, l1);

    while (AccelStepper_Run(axis->stepper)) {
        float p = Axis_GetPosition_mm(axis);
        char l2[17];
        snprintf(l2, sizeof(l2), "%c Pos:%7.2f", spin[si], p);
        si = (si + 1) & 3;

        I2C_LCD_SetCursor(LCD, 0, 1);
        I2C_LCD_WriteString(LCD, l2);
        HAL_Delay(20);
    }
}

/* Command a motion in machine mm and wait until done. */
static HAL_StatusTypeDef move_abs_and_wait(LinearAxis_t *axis, float target_mm)
{
    target_mm = clampf(target_mm, AXIS_MIN_MM, AXIS_MAX_MM);
    HAL_StatusTypeDef st = Axis_MoveAbsolute(axis, target_mm);
    if (st != HAL_OK) return st;

    wait_to_target_with_lcd(axis, "Moving...");
    return HAL_OK;
}

/* -------------------- Core Interaction -------------------- */

static void compute_window(RandomTestParams_t *p)
{
    // Clamp requested symmetric stroke inside machine limits
    float lo = clampf(p->null_machine_mm - p->stroke_range_mm, AXIS_MIN_MM, AXIS_MAX_MM);
    float hi = clampf(p->null_machine_mm + p->stroke_range_mm, AXIS_MIN_MM, AXIS_MAX_MM);
    p->logical_min_mm = lo;
    p->logical_max_mm = hi;
}

/* Manual loop: user types RELATIVE mm (e.g., -10.0 .. +10.0) */
static void manual_loop(LinearAxis_t *axis, const RandomTestParams_t *p)
{
    char l1[17], l2[17];

    while (1) {
        // Show current and limits
        float cur = Axis_GetPosition_mm(axis);
        float rel = cur - p->null_machine_mm;

//        I2C_LCD_Clear(I2C_LCD_1);
//        I2C_LCD_SetCursor(I2C_LCD_1, 0,0);
//        snprintf(l1, sizeof(l1), "Null:%6.2fmm", cur);
//        I2C_LCD_WriteString(I2C_LCD_1, Str);

        snprintf(l1, sizeof(l1), "Cur:%6.2fmm", cur);
        snprintf(l2, sizeof(l2), "Rel:%+5.2f U/E/C", rel);
        lcd_two_lines(l1, l2);

        HAL_Delay(1000);

        // Prompt for relative target around Null
        float rel_target = 0.0f;
        if (!prompt_float("Rel mm (-/+):", "mm", &rel_target)) {
            // Cancel/back: return to main menu
            lcd_two_lines("Manual Exit", "");
            HAL_Delay(300);
            return;
        }

        // Map to machine
        float mach_target = p->null_machine_mm + rel_target;
        // Clamp inside logical window
        if (mach_target < p->logical_min_mm) mach_target = p->logical_min_mm;
        if (mach_target > p->logical_max_mm) mach_target = p->logical_max_mm;

        // Show target and move
        char msg[17];
        snprintf(msg, sizeof(msg), "Go:%7.2fmm", mach_target);
        I2C_LCD_Clear(LCD);
        I2C_LCD_SetCursor(LCD, 0, 0);
        I2C_LCD_WriteString(LCD, msg);
        I2C_LCD_SetCursor(LCD, 0, 1);
        I2C_LCD_WriteString(LCD, "Moving...");

        if (move_abs_and_wait(axis, mach_target) != HAL_OK) {
            lcd_two_lines("Move error", "Check limits");
            HAL_Delay(800);
            return;
        }

        // Done screen with absolute & relative
        float newPos = Axis_GetPosition_mm(axis);
        float newRel = newPos - p->null_machine_mm;
        snprintf(l1, sizeof(l1), "At:%7.2fmm", newPos);
        snprintf(l2, sizeof(l2), "Rel:%+6.2f", newRel);
        lcd_two_lines(l1, l2);
        HAL_Delay(500);
    }
}

/* Random loop: generate random targets inside window.
 * - Press E to move to a new random position
 * - Press C to exit to main menu
 * - Press U to switch to Manual directly
 */
static void random_loop(LinearAxis_t *axis, const RandomTestParams_t *p)
{
    // seed once per entry (weak PRNG, but fine for UI)
    static uint32_t seeded = 0;
    if (!seeded) { srand(HAL_GetTick()); seeded = 1; }

    float last_target = Axis_GetPosition_mm(axis);

    while (1) {
        char l1[17], l2[17];
        float cur = Axis_GetPosition_mm(axis);
        float rel = cur - p->null_machine_mm;

        snprintf(l1, sizeof(l1), "R:%4.1f..%4.1f",
                 p->logical_min_mm, p->logical_max_mm);
        snprintf(l2, sizeof(l2), "CurR:%+6.2f", rel);
        lcd_two_lines(l1, l2);

        // Wait for key
        char k = 0;
        do {
            k = keypad_poll_edge();
            HAL_Delay(LOOP_SLEEP_MS);
        } while (k == 0);

        if (k == 'C') {
            lcd_two_lines("Random Exit", "");
            HAL_Delay(300);
            return;
        } else if (k == 'U') {
            // Switch to manual
            manual_loop(axis, p);
            continue;
        } else if (k == 'E') {
            // New random machine target within logical window.
            // Spread uniformly; avoid very tiny moves vs last_target.
            float lo = p->logical_min_mm;
            float hi = p->logical_max_mm;
            float t = lo + ((float)rand() / (float)RAND_MAX) * (hi - lo);

            // If too close to previous, push to opposite half for visibility
            if (fabsf(t - last_target) < 0.5f) {
                float mid = 0.5f * (lo + hi);
                if (t < mid) t = mid + 0.5f;
                else         t = mid - 0.5f;
                t = clampf(t, lo, hi);
            }

            last_target = t;

            char msg[17];
            snprintf(msg, sizeof(msg), "Rnd:%7.2fmm", t);
            I2C_LCD_Clear(LCD);
            I2C_LCD_SetCursor(LCD, 0, 0);
            I2C_LCD_WriteString(LCD, msg);
            I2C_LCD_SetCursor(LCD, 0, 1);
            I2C_LCD_WriteString(LCD, "Moving...");

            if (move_abs_and_wait(axis, t) != HAL_OK) {
                lcd_two_lines("Move error", "Check limits");
                HAL_Delay(800);
                return;
            }

            // Motion has completed. Measure the ADC at this position.
            float newPos = Axis_GetPosition_mm(axis);

            random_test_show_measurement(newPos);

            HAL_Delay(1500);
        }
    }
}

/* -------------------- Public Entry -------------------- */

RandomTestResult Random_Test_Run(LinearAxis_t *axis, RandomTestParams_t *ioParams)
{
	if ((axis == NULL) || (Axis_IsHomed(axis) == false))
	    {
	        lcd_two_lines("Axis NOT homed", "Abort");
	        HAL_Delay(1000U);
	        return RANDOM_TEST_ERROR;
	    }

	    RandomTestParams_t p = {0};
	    if (ioParams != NULL)
	    {
	        p = *ioParams;
	    }

	    float null_mm = 0.0f;

	    /* Use previously validated Null if available */
	    if ((ioParams != NULL) && (ioParams->null_is_valid == true))
	    {
	        null_mm = ioParams->null_machine_mm;
	    }
	    else
	    {
	        NullSetResult nres = Null_SetNewReference(axis, &null_mm);

	        if (nres == NULL_SET_ABORTED)
	        {
	            /* Optional: fall back to global Null if it is valid */
	            if ((Get_LVDT_boll() == true) && (Get_LVDT_null() != 0.0f))
	            {
	                null_mm = Get_LVDT_null();
	                /* continue with previous Null – or decide to abort */
	            }
	            else
	            {
	                lcd_two_lines("Null cancelled", "Exit Test");
	                HAL_Delay(600U);
	                return RANDOM_TEST_ABORTED;
	            }
	        }
	        else if (nres != NULL_SET_OK)
	        {
	            lcd_two_lines("Null failed", "Abort");
	            HAL_Delay(800U);
	            return RANDOM_TEST_ERROR;
	        }
	    }

	    p.null_machine_mm = null_mm;
	    p.null_is_valid   = true;

	    /* 2) Get user inputs (Stroke, Excitation, OpDisp) — rest unchanged */
	    if (p.stroke_range_mm <= 0.0f) {
	        if (!prompt_float("Stroke (+/-mm):", "mm", &p.stroke_range_mm)) {
	            lcd_two_lines("Stroke cancel", "Exit");
	            HAL_Delay(400);
	            return RANDOM_TEST_ABORTED;
	        }
	    }
    // Excitation Voltage (store only)
    if (p.excitation_voltage_v <= 0.0f) {
        if (!prompt_float("Exc.V (V):", "V", &p.excitation_voltage_v)) {
            lcd_two_lines("Exc.V cancel", "Exit");
            HAL_Delay(400);
            return RANDOM_TEST_ABORTED;
        }
    }

    // Operational Displacement (store only)
    if (p.op_displacement_mm <= 0.0f) {
        if (!prompt_float("OpDisp (mm):", "mm", &p.op_displacement_mm)) {
            lcd_two_lines("OpDisp cancel", "Exit");
            HAL_Delay(400);
            return RANDOM_TEST_ABORTED;
        }
    }

    /* 3) Compute logical window [null - stroke, null + stroke] clamped to [0..500] */
    compute_window(&p);

    // Show summary
    {
        char l1[17], l2[17];
        snprintf(l1, sizeof(l1), "Null:%7.2f", p.null_machine_mm);
        snprintf(l2, sizeof(l2), "W:%4.1f..%4.1f", p.logical_min_mm, p.logical_max_mm);
        lcd_two_lines(l1, l2);
        HAL_Delay(900);
    }

    /* 4) Mode selection loop */
    while (1) {
        lcd_two_lines("Random Test", "U:Manual R:Rand");

        // also allow C to exit
        char k = 0;
        do {
            k = keypad_poll_edge();
            HAL_Delay(LOOP_SLEEP_MS);
        } while (k == 0);

        if (k == 'C') {
            lcd_two_lines("Test Exit", "");
            HAL_Delay(300);
            if (ioParams) *ioParams = p;
            return RANDOM_TEST_OK;
        } else if (k == 'U') {
            manual_loop(axis, &p);
        } else if (k == 'R') {
            random_loop(axis, &p);
        } else {
            // ignore other keys
        }
    }
}

