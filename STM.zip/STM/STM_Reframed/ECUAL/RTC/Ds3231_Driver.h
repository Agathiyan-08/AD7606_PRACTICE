#ifndef DS3231_H_
#define DS3231_H_

#include "stm32f4xx_hal.h"   // Change based on your MCU

// ================= STRUCT =================
typedef struct {
    uint8_t seconds;
    uint8_t minutes;
    uint8_t hour;
    uint8_t dayofweek;
    uint8_t dayofmonth;
    uint8_t month;
    uint8_t year;
} DS3231_Time;

// ================= USER FUNCTIONS =================

// Initialize DS3231 (pass I2C handle)
void DS3231_Init(I2C_HandleTypeDef *hi2c);

// Set time
void DS3231_SetTime(DS3231_Time *time);

// Get time
void DS3231_GetTime(DS3231_Time *time);

// Get temperature
float DS3231_GetTemperature(void);

// Force temperature conversion
void DS3231_ForceTemperature(void);

#endif /* DS3231_H_ */
