/*
 * ballscrew_config.h
 *
 *  Created on: Mar 6, 2026
 *      Author: Admin
 */

#ifndef LINEAR_AXIS_BALLSCREW_CONFIG_H_
#define LINEAR_AXIS_BALLSCREW_CONFIG_H_

// ballscrew_config.h
#define STEPS_PER_REV       1600
#define BALLSCREW_PITCH_MM  5.0f
#define STEPS_PER_MM        (STEPS_PER_REV / BALLSCREW_PITCH_MM)   // = 320.0f

// Inline conversion utilities (no function call overhead)
#define MM_TO_STEPS(mm)     ((int32_t)((mm) * STEPS_PER_MM))
#define STEPS_TO_MM(steps)  ((float)(steps) / STEPS_PER_MM)

#endif /* LINEAR_AXIS_BALLSCREW_CONFIG_H_ */
