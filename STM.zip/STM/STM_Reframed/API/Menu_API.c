/*
 * Menu_API.c
 *
 *  Created on: Mar 12, 2026
 *      Author: Admin
 */

#include "Menu_API.h"
#include <stdio.h>

#include "stm32f4xx_hal.h"
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"
#include "User_Input_API.h"  // KEYPAD_Input_Init(), KEYPAD_Input_Get()

#include <string.h>
#include <ctype.h>

/* ====== Layout configuration (tweak for your LCD width) ====== */
#define LCD_INST          I2C_LCD_1
#define LCD_COLS          16
#define LCD_ROWS          2

/* Where to place the prompt and echo the digits */
#define PROMPT_ROW        1
#define PROMPT_COL        0

/* Helper: print a truncated string */
static void lcd_print_fit(uint8_t col, uint8_t row, const char* s)
{
    I2C_LCD_SetCursor(LCD_INST, col, row);
    char buf[LCD_COLS + 1];
    memset(buf, ' ', sizeof(buf));
    buf[LCD_COLS] = '\0';
    size_t n = strlen(s);
    if (n > LCD_COLS) n = LCD_COLS;
    memcpy(buf, s, n);
    I2C_LCD_WriteString(LCD_INST, buf);
}

void MENU_Init(void)
{
    /* If LCD was already initialized elsewhere, you can remove this */
    I2C_LCD_Init(LCD_INST);

    /* Prepare keypad input buffer and LCD cursor defaults */
    KEYPAD_Input_Init();
}

/**
 * A compact two-line layout:
 * Line0: "1)Rand 2)Cyc"
 * Line1: "3)Cal Sel:"   (cursor placed right after)
 */
void MENU_Show(const menu_item_t* items, uint8_t count)
{
    (void)count; // We design for 3, but code is generic

    I2C_LCD_Clear(LCD_INST);

    /* Compose first row: show first two items */
    char line0[17] = {0};
    // Keep labels short to fit 16 chars total
    // Example layout: "1)Rand 2)Cyc"
    snprintf(line0, sizeof(line0), "1)%s 2)%s",
             (items && items[0].label) ? items[0].label : "Opt1",
             (count > 1 && items[1].label) ? items[1].label : "Opt2");
    lcd_print_fit(0, 0, line0);

    /* Compose second row: show third + prompt */
    char line1[17] = {0};
    // Example: "3)Cal Sel:"
    snprintf(line1, sizeof(line1), "3)%s Sel:",
            (count > 2 && items[2].label) ? items[2].label : "Opt3");
    lcd_print_fit(0, 1, line1);

    /* Place cursor at the end of "Sel:" so KEYPAD_Input_Get() echoes there */
    size_t len = strlen(line1);
    uint8_t col = (len < LCD_COLS) ? (uint8_t)len : (LCD_COLS - 1);
    I2C_LCD_SetCursor(LCD_INST, col, PROMPT_ROW);
}

/**
 * Returns:
 *  >=0 : selected index
 *  -1  : timeout
 *  -2  : invalid (only returned when timeout_ms > 0; otherwise
 *        we show error and stay in the loop until a valid entry is made)
 */
int8_t MENU_WaitForSelection(const menu_item_t* items, uint8_t count, uint32_t timeout_ms)
{
    uint32_t start = HAL_GetTick();

    /* We expect the user to press a single digit (1..count) then 'E'.
       KEYPAD_Input_Get() will return a char* buffer when E is pressed. */
    while (1)
    {
        if (timeout_ms > 0)
        {
            uint32_t now = HAL_GetTick();
            if ((now - start) >= timeout_ms)
                return -1; // timeout
        }

        char* s = KEYPAD_Input_Get();   // returns NULL until user presses 'E'
        if (s == NULL)
        {
            continue; // still waiting
        }

        /* We accept the first digit we find in s. */
        int chosen = -2; // invalid by default
        for (size_t i = 0; s[i] != '\0'; ++i)
        {
            if (isdigit((unsigned char)s[i]))
            {
                int val = s[i] - '0';
                if (val >= 1 && val <= count)
                {
                    chosen = val - 1;
                }
                break;
            }
        }

        if (chosen >= 0)
        {
            /* Valid selection */
            return (int8_t)chosen;
        }
        else
        {
            /* Invalid -> tell the user */
            I2C_LCD_Clear(LCD_INST);
            lcd_print_fit(0, 0, "Invalid Option");
            lcd_print_fit(0, 1, "Press any key");
            HAL_Delay(700);

            /* Redraw the menu and keep waiting unless we had a timeout */
            MENU_Show(items, count);
            if (timeout_ms > 0)
            {
                return -2; // let caller decide
            }
        }
    }
}

/* Blocking runner: keeps showing the menu, waits, executes, then returns to menu */
void MENU_Run(const menu_item_t* items, uint8_t count)
{
    MENU_Show(items, count);

    while (1)
    {
        int8_t idx = MENU_WaitForSelection(items, count, 0); // no timeout
        if (idx >= 0 && idx < count && items[idx].action)
        {
            /* Clear and show which option was selected */
            I2C_LCD_Clear(LCD_INST);

            char msg0[17] = {0};
            snprintf(msg0, sizeof(msg0), "Selected: %c)", items[idx].number);

            lcd_print_fit(0, 0, msg0);
            lcd_print_fit(0, 1, items[idx].label ? items[idx].label : "Running");

            /* Execute handler */
            items[idx].action();

            /* After the task, return to the menu */
            HAL_Delay(500);
            KEYPAD_Input_Init();  // reset input buffer & cursor (will be overwritten by MENU_Show)
            MENU_Show(items, count);
        }
        else
        {
            // Shouldn't happen in normal flow; redraw menu
            MENU_Show(items, count);
        }
    }
}


