#ifndef STEPPER_HOMING_H
#define STEPPER_HOMING_H

#include "../../ECUAL/Limit_Switch/Limit_Switch_Driver.h"
#include "../../ECUAL/STEPPER_MOTOR/stepper_motor_API.h"   // your stepper driver header
#include "../../ECUAL/Linear_Axis/ballscrew_config.h"

/* Machine configuration */

//#define STEPS_PER_REV        1600
//#define SCREW_PITCH_MM       5

//#define STEPS_PER_MM         (STEPS_PER_REV / SCREW_PITCH_MM)

#define HOMING_CLEARANCE_MM  1
#define HOMING_CLEARANCE_STEPS (HOMING_CLEARANCE_MM * STEPS_PER_MM)

#define MAX_TRAVEL_MM        350
#define MAX_HOMING_STEPS     (MAX_TRAVEL_MM * STEPS_PER_MM)

#define HOMING_STEP_DELAY_US 100


typedef struct
{
    Stepper_HandleTypeDef *stepper;
    float position_mm;

}Axis_HandleTypeDef;


typedef enum
{
    HOMING_OK = 0,
    HOMING_TIMEOUT

}HomingStatus;


HomingStatus Axis_Home(Axis_HandleTypeDef *axis);

#endif
