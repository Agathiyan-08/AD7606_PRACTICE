#include "Limit_Switch_Driver.h"

uint8_t LimitSwitch_Read(void)
{
    GPIO_PinState state;

    state = HAL_GPIO_ReadPin(LIMIT_SWITCH_PORT, LIMIT_SWITCH_PIN);

#if LIMIT_SWITCH_ACTIVE_STATE
    return (state == GPIO_PIN_SET);
#else
    return (state == GPIO_PIN_RESET);
#endif
}

uint8_t LimitSwitch_ReadDebounced(void)
{
    uint8_t count = 0;

    for(uint8_t i = 0; i < LIMIT_SWITCH_DEBOUNCE_COUNT; i++)
    {
        if(LimitSwitch_Read())
        {
            count++;
        }

        HAL_Delay(1);

    }

    return (count == LIMIT_SWITCH_DEBOUNCE_COUNT);
}
