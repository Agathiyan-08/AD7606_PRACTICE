#include "../../API/User_Input_API.h"
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"
#include "../../ECUAL/KEYPAD/KEYPAD.h"
#include <string.h>



extern uint8_t KeyStates[16];
extern uint8_t prevKeyStates[16];

static char buffer[KEYPAD_INPUT_MAX_LEN];

static char result[KEYPAD_INPUT_MAX_LEN];

static uint8_t Arr_index = 0;

const char KeyMap[ROWS][COLS] =
{
    {'1','2','3','U'},
    {'4','5','6','D'},
    {'7','8','9','-'},
    {'C','0','E','.'}
};

//----------------------------------

void KEYPAD_Input_Init(void)
{
    Arr_index = 0;
    memset(buffer, 0, sizeof(buffer));

    I2C_LCD_Clear(I2C_LCD_1);
    I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
}

//----------------------------------

char* KEYPAD_Input_Get(void)
{
    KEYPAD_Scan(0);

    for(int i = 0; i < 16; i++)
    {
    	if(KeyStates[i] == KEY_PRESSED && prevKeyStates[i] == KEY_RELEASED)
        {

    	    HAL_Delay(20);  // 🔴 debounce delay

    	    // Re-scan keypad after delay to confirm key state
    	    KEYPAD_Scan(0);

    	    // Re-check to confirm stable press
    	    if(KeyStates[i] != KEY_PRESSED)
    	        continue;

            int row = i / 4;
            int col = i % 4;

            char key = KeyMap[row][col];

            // CLEAR
            if(key == 'C')
            {
                Arr_index = 0;
                memset(buffer, 0, sizeof(buffer));

                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
            }

            // ENTER
            else if(key == 'E')
            {
                buffer[Arr_index] = '\0';

                strcpy(result, buffer);   // 🔴 store safely

                Arr_index = 0;
                memset(buffer, 0, sizeof(buffer));

                return result;
            }

            // NORMAL / U / D
            else
            {
                if(Arr_index < KEYPAD_INPUT_MAX_LEN - 1)
                {
                    buffer[Arr_index++] = key;

                    I2C_LCD_WriteChar(I2C_LCD_1, key);
                }
            }
        }

        prevKeyStates[i] = KeyStates[i];
    }

    return 0;   // no data
}
