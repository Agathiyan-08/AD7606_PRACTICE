/*
 * AccelStepper_STM32.h
 *
 *  AccelStepper-style API for STM32 — pure GPIO, no timer peripheral.
 *
 *  Mirrors the Arduino AccelStepper library interface so the usage
 *  pattern is familiar:
 *
 *      AccelStepper_SetMaxSpeed(&motor,    4000.0f);
 *      AccelStepper_SetAcceleration(&motor, 2000.0f);
 *      AccelStepper_MoveTo(&motor, 800);
 *
 *      while (1) {
 *          AccelStepper_Run(&motor);   // non-blocking — call every loop
 *      }
 *
 *  Key design decisions:
 *    - Speed/accel changes take effect IMMEDIATELY mid-move (recomputes ramp)
 *    - Position is tracked as a signed 32-bit integer (like AccelStepper)
 *    - Run() uses DWT microsecond timing — accurate at all speeds
 *    - No timer peripheral, no ISR, no CubeMX timer config needed
 */

#ifndef ACCELSTEPPER_STM32_H_
#define ACCELSTEPPER_STM32_H_

#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "../../ECUAL/STEPPER_MOTOR/stepper_motor_API.h"

#ifdef __cplusplus
extern "C" {
#endif

/* =========================================================================
 * HANDLE
 * ========================================================================= */

/**
 * @brief  AccelStepper motor handle.
 *         Declare one per motor. Pass pointer to every API function.
 *         Do not modify fields directly — use the API functions.
 */
typedef struct
{
    /* ── Hardware reference (your existing stepper handle) ── */
    Stepper_HandleTypeDef *hw;              /**< Pointer to GPIO pin config        */

    /* ── Motion parameters (set via API — change anytime) ── */
    float    max_speed;                     /**< Cruise speed      steps/sec       */
    float    acceleration;                  /**< Ramp rate         steps/sec^2     */

    /* ── Position tracking ── */
    int32_t  current_pos;                   /**< Absolute position in steps        */
    int32_t  target_pos;                    /**< Target position set by MoveTo()   */

    /* ── Internal motion state ── */
    float    current_speed;                 /**< Instantaneous speed   steps/sec   */
    float    step_interval_us;             /**< Current delay between steps (µs)  */
    uint32_t last_step_time_us;            /**< DWT timestamp of last step        */
    int8_t   direction;                    /**< +1 = CW, -1 = CCW                 */

    /* ── Computed ramp state (recomputed when params change) ── */
    float    min_step_interval_us;         /**< At max_speed (fastest)            */
    float    sqrt_2a;                      /**< sqrt(2 * acceleration) cached     */

    /* ── Status flags ── */
    bool     enabled;                      /**< Motor driver enabled              */
    bool     running;                      /**< True if move in progress          */

    /* ── Completion callback ── */
    void (*on_target_reached)(void);

} AccelStepper_Handle_t;

/* =========================================================================
 * PUBLIC API — matches AccelStepper library naming
 * ========================================================================= */

/**
 * @brief  Initialize the AccelStepper handle.
 *
 * @param  h    Pointer to AccelStepper_Handle_t (caller allocates)
 * @param  hw   Pointer to your Stepper_HandleTypeDef (GPIO config)
 *
 * @note   Call Stepper_Enable() separately when ready to power the motor.
 *         DWT cycle counter is initialized here automatically.
 */
void AccelStepper_Init(AccelStepper_Handle_t *h, Stepper_HandleTypeDef *hw);

/**
 * @brief  Set maximum (cruise) speed in steps/sec.
 *         Takes effect immediately — ramp recomputes from current speed.
 *
 * @param  h      Handle
 * @param  speed  Steps per second (e.g. 4000.0 = 300 RPM at 800 steps/rev)
 */
void AccelStepper_SetMaxSpeed(AccelStepper_Handle_t *h, float speed);

/**
 * @brief  Set acceleration/deceleration rate in steps/sec^2.
 *         Takes effect immediately — ramp recomputes.
 *
 * @param  h      Handle
 * @param  accel  Steps per second squared (e.g. 2000.0)
 */
void AccelStepper_SetAcceleration(AccelStepper_Handle_t *h, float accel);

/**
 * @brief  Set absolute target position.
 *         Motor will move to this position using the configured speed/accel.
 *         Direction is set automatically.
 *
 * @param  h    Handle
 * @param  pos  Target position in steps (signed, relative to zero/home)
 */
void AccelStepper_MoveTo(AccelStepper_Handle_t *h, int32_t pos);

/**
 * @brief  Move relative to current position.
 *         Equivalent to MoveTo(currentPosition + steps).
 *
 * @param  h      Handle
 * @param  steps  Steps to move (positive = CW, negative = CCW)
 */
void AccelStepper_Move(AccelStepper_Handle_t *h, int32_t steps);

/**
 * @brief  NON-BLOCKING run — call this every iteration of while(1).
 *
 *         Checks if it is time for the next step using DWT timing.
 *         If yes: steps motor, updates position, recomputes speed for ramp.
 *         If no:  returns immediately without blocking.
 *
 *         Returns true if the motor is still moving, false if target reached.
 *
 * @param  h  Handle
 * @return    true  = motor still moving toward target
 *            false = target reached, motor stopped
 */
bool AccelStepper_Run(AccelStepper_Handle_t *h);

/**
 * @brief  BLOCKING run — waits until target position is reached.
 *         Calls Run() in a tight loop internally.
 *         Use when you want to wait for a move to complete before continuing.
 *
 * @param  h  Handle
 */
void AccelStepper_RunToPosition(AccelStepper_Handle_t *h);

/**
 * @brief  Blocking move to absolute position — combined MoveTo + RunToPosition.
 *
 * @param  h    Handle
 * @param  pos  Absolute target position
 */
void AccelStepper_RunToNewPosition(AccelStepper_Handle_t *h, int32_t pos);

/**
 * @brief  Immediately stop the motor (no deceleration ramp).
 *         Sets target = current position. May lose steps.
 *         Use only for emergency stops.
 */
void AccelStepper_Stop(AccelStepper_Handle_t *h);

/**
 * @brief  Decelerated stop — adjusts target so motor decelerates to a halt.
 *         Calculates minimum stopping distance from current speed and sets
 *         target accordingly. Motor stops smoothly.
 */
void AccelStepper_StopSmooth(AccelStepper_Handle_t *h);

/**
 * @brief  Enable motor driver (assert ENA pin LOW for Common Cathode T60).
 */
void AccelStepper_Enable(AccelStepper_Handle_t *h);

/**
 * @brief  Disable motor driver (de-assert ENA pin). Motor freewheels.
 */
void AccelStepper_Disable(AccelStepper_Handle_t *h);

/**
 * @brief  Get current absolute position.
 * @return Signed step count
 */
int32_t AccelStepper_CurrentPosition(AccelStepper_Handle_t *h);

/**
 * @brief  Get distance remaining to target.
 * @return target_pos - current_pos (signed — negative means moving CCW)
 */
int32_t AccelStepper_DistanceToGo(AccelStepper_Handle_t *h);

/**
 * @brief  Get target position.
 */
int32_t AccelStepper_TargetPosition(AccelStepper_Handle_t *h);

/**
 * @brief  Get current instantaneous speed in steps/sec.
 */
float AccelStepper_CurrentSpeed(AccelStepper_Handle_t *h);

/**
 * @brief  Set current position without moving. Useful for homing.
 *         Resets both current_pos and target_pos to the given value.
 *
 * @param  h    Handle
 * @param  pos  New position value
 */
void AccelStepper_SetCurrentPosition(AccelStepper_Handle_t *h, int32_t pos);

/**
 * @brief  Returns true if motor is currently moving toward target.
 */
bool AccelStepper_IsRunning(AccelStepper_Handle_t *h);

/**
 * @brief  Register callback fired when target position is reached.
 * @param  cb  Function pointer (NULL to disable)
 */
void AccelStepper_RegisterTargetCallback(AccelStepper_Handle_t *h,
                                          void (*cb)(void));

#ifdef __cplusplus
}
#endif

#endif /* ACCELSTEPPER_STM32_H_ */
