################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../API/Calibration_API.c \
../API/Calibration_Test_API.c \
../API/Cyclic_test_API.c \
../API/Homing_API.c \
../API/Menu_API.c \
../API/Null_Process_API.c \
../API/Random_Test_API.c \
../API/User_Input_API.c 

OBJS += \
./API/Calibration_API.o \
./API/Calibration_Test_API.o \
./API/Cyclic_test_API.o \
./API/Homing_API.o \
./API/Menu_API.o \
./API/Null_Process_API.o \
./API/Random_Test_API.o \
./API/User_Input_API.o 

C_DEPS += \
./API/Calibration_API.d \
./API/Calibration_Test_API.d \
./API/Cyclic_test_API.d \
./API/Homing_API.d \
./API/Menu_API.d \
./API/Null_Process_API.d \
./API/Random_Test_API.d \
./API/User_Input_API.d 


# Each subdirectory must supply rules for building sources it contributes
API/%.o API/%.su API/%.cyclo: ../API/%.c API/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-API

clean-API:
	-$(RM) ./API/Calibration_API.cyclo ./API/Calibration_API.d ./API/Calibration_API.o ./API/Calibration_API.su ./API/Calibration_Test_API.cyclo ./API/Calibration_Test_API.d ./API/Calibration_Test_API.o ./API/Calibration_Test_API.su ./API/Cyclic_test_API.cyclo ./API/Cyclic_test_API.d ./API/Cyclic_test_API.o ./API/Cyclic_test_API.su ./API/Homing_API.cyclo ./API/Homing_API.d ./API/Homing_API.o ./API/Homing_API.su ./API/Menu_API.cyclo ./API/Menu_API.d ./API/Menu_API.o ./API/Menu_API.su ./API/Null_Process_API.cyclo ./API/Null_Process_API.d ./API/Null_Process_API.o ./API/Null_Process_API.su ./API/Random_Test_API.cyclo ./API/Random_Test_API.d ./API/Random_Test_API.o ./API/Random_Test_API.su ./API/User_Input_API.cyclo ./API/User_Input_API.d ./API/User_Input_API.o ./API/User_Input_API.su

.PHONY: clean-API

