/*
 * ad7606.h
 *
 *  Created on: May 15, 2026
 *
 */

#ifndef INC_AD7606_H_
#define INC_AD7606_H_
#include "main.h"
#include "stm32f4xx.h"

extern SPI_HandleTypeDef hspi3;

#define RAW_DATA_SIZE           8U
#define RAW_DATA_BYTES          (RAW_DATA_SIZE * 2U)
#define AD7606_BUSY_TIMEOUT_MS  50U

// Select the AD7606 Output range
#define AD7606_INPUT_RANGE_V  10.0f

//#define VOLT			(float)5.0
//#define VOLTAGE_OFF		(float)(VOLT/32677);

#define CA_PORT         ADC_CVA_GPIO_Port
#define CA_PIN          ADC_CVA_Pin
#define CB_PORT         ADC_CVB_GPIO_Port
#define CB_PIN          ADC_CVB_Pin

#define OS0_PIN         ADC_OS0_Pin
#define OS0_PORT        ADC_OS0_GPIO_Port
#define OS1_PIN         ADC_OS1_Pin
#define OS1_PORT        ADC_OS1_GPIO_Port
#define OS2_PIN         ADC_OS2_Pin
#define OS2_PORT        ADC_OS2_GPIO_Port

#define CS_PORT         ADC_CS_GPIO_Port
#define CS_PIN          ADC_CS_Pin

#define BUSY_PORT       ADC_Busy_GPIO_Port
#define BUSY_PIN        ADC_Busy_Pin

#define RESET_PORT      ADC_RST_GPIO_Port
#define RESET_PIN       ADC_RST_Pin

#define RANGE_PORT      ADC_Range_GPIO_Port
#define RANGE_PIN       ADC_Range_Pin

typedef enum
{
    OVERSAMPLING0 = 0U,
    OVERSAMPLING2,
    OVERSAMPLING4,
    OVERSAMPLING8,
    OVERSAMPLING16,
    OVERSAMPLING32,
    OVERSAMPLING64
} AD7606_Oversampling_t;

/*--------------------------------------------------------------------------
 * Public function prototypes
 *------------------------------------------------------------------------*/
void ConvAB_Init(void);
void ResetAD7606(void);
void OverSamplingEn(uint8_t os);
void AD7606ConvStAB(void);
void CS_Di(void);
void CS_En(void);

/**
 * @brief  Trigger conversion, wait for BUSY, read 8 channels via SPI
 * @param  adc_raw  Pointer to array of at least AD7606_RAW_DATA_SIZE elements
 * @return 0 on success, non-zero on timeout / error
 */
HAL_StatusTypeDef AD7606_ADC(int16_t *adcRaw);

/**
 * @brief  Convert raw ADC values to voltage and print via UART
 * @param  voltage  Output array (must be at least AD7606_RAW_DATA_SIZE)
 * @param  adc_raw  Input raw values
 */

void Data_Conv(float *voltage, const int16_t *adcRaw);

/**
 * @brief  Driver Init function
 * @param  voltage  Output array (must be at least AD7606_RAW_DATA_SIZE)
 * @param  adc_raw  Input raw values
 */
void AD7606_Init(void);

/**
 * @brief  Perform one conversion and verify ADC responds (BUSY clears).
 * @return 0U = OK (connected / working), 1U = timeout / not responding
 */
uint8_t AD7606_IsConnected(void);


#endif /* INC_AD7606_H_ */
