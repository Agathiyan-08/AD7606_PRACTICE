################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ECUAL/STEPPER_MOTOR/Stepper_Config.c \
../ECUAL/STEPPER_MOTOR/stepper_motor_API.c 

OBJS += \
./ECUAL/STEPPER_MOTOR/Stepper_Config.o \
./ECUAL/STEPPER_MOTOR/stepper_motor_API.o 

C_DEPS += \
./ECUAL/STEPPER_MOTOR/Stepper_Config.d \
./ECUAL/STEPPER_MOTOR/stepper_motor_API.d 


# Each subdirectory must supply rules for building sources it contributes
ECUAL/STEPPER_MOTOR/%.o ECUAL/STEPPER_MOTOR/%.su ECUAL/STEPPER_MOTOR/%.cyclo: ../ECUAL/STEPPER_MOTOR/%.c ECUAL/STEPPER_MOTOR/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-ECUAL-2f-STEPPER_MOTOR

clean-ECUAL-2f-STEPPER_MOTOR:
	-$(RM) ./ECUAL/STEPPER_MOTOR/Stepper_Config.cyclo ./ECUAL/STEPPER_MOTOR/Stepper_Config.d ./ECUAL/STEPPER_MOTOR/Stepper_Config.o ./ECUAL/STEPPER_MOTOR/Stepper_Config.su ./ECUAL/STEPPER_MOTOR/stepper_motor_API.cyclo ./ECUAL/STEPPER_MOTOR/stepper_motor_API.d ./ECUAL/STEPPER_MOTOR/stepper_motor_API.o ./ECUAL/STEPPER_MOTOR/stepper_motor_API.su

.PHONY: clean-ECUAL-2f-STEPPER_MOTOR

