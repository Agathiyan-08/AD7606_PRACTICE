/*
 * Menu_API.h
 *
 *  Created on: Mar 12, 2026
 *      Author: Admin
 */

#ifndef MENU_API_H_
#define MENU_API_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*menu_action_t)(void);

typedef struct {
    char number;          // '1','2','3'
    const char* label;    // Short label for LCD
    menu_action_t action; // Function to call on selection
} menu_item_t;

/**
 * @brief Initialize Menu API (LCD init + keypad input init).
 *        Call this once after HAL/I2C/GPIO are initialized.
 */
void MENU_Init(void);

/**
 * @brief Show menu on LCD (2-line layout) and place cursor at input position.
 *        This does not block.
 */
void MENU_Show(const menu_item_t* items, uint8_t count);

/**
 * @brief Block until a valid selection is made (digit+E).
 * @param items  Menu table
 * @param count  Number of items (3 in your case)
 * @param timeout_ms  0 = no timeout, otherwise timeout in ms
 * @return index (0..count-1) on success, -1 on timeout, -2 on invalid (then it redraws and waits again if timeout==0)
 */
int8_t MENU_WaitForSelection(const menu_item_t* items, uint8_t count, uint32_t timeout_ms);

/**
 * @brief Convenience API: show menu, wait for selection, run handler, then show menu again.
 *        This blocks forever in a loop.
 */
void MENU_Run(const menu_item_t* items, uint8_t count);

#ifdef __cplusplus
}
#endif


#endif /* MENU_API_H_ */
