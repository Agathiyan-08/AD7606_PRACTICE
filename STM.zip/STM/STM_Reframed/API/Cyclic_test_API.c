/*
 * Cyclic_test_API.c
 *
 *  Created on: Mar 16, 2026
 *      Author: thara
 */

#include "Cyclic_Test_API.h"
#include "Null_Process_API.h"
#include "User_Input_API.h"
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LCD I2C_LCD_1

#define AXIS_MIN_MM 0.0f
#define AXIS_MAX_MM 500.0f

#define LOOP_SLEEP_MS 5

/*--------------------------------------------------*/
/* LCD Helper */
/*--------------------------------------------------*/

static void lcd_two_lines(const char *l1, const char *l2)
{
    I2C_LCD_Clear(LCD);

    I2C_LCD_SetCursor(LCD,0,0);
    I2C_LCD_WriteString(LCD,(char*)l1);

    I2C_LCD_SetCursor(LCD,0,1);
    I2C_LCD_WriteString(LCD,(char*)l2);
}

/*--------------------------------------------------*/
/* Float Parser */
/*--------------------------------------------------*/

static bool parse_float(const char* s, float *out)
{
    if(!s) return false;

    char *endp;

    float v = strtof(s,&endp);

    if(endp == s)
        return false;

    *out = v;

    return true;
}

/*--------------------------------------------------*/
/* Float Input Prompt */
/*--------------------------------------------------*/

static bool prompt_float(const char *title,float *out)
{
    I2C_LCD_Clear(LCD);

    I2C_LCD_SetCursor(LCD,0,0);
    I2C_LCD_WriteString(LCD,(char*)title);

    I2C_LCD_SetCursor(LCD,0,1);
    I2C_LCD_WriteString(LCD,"Type.. #=OK");

    while(1)
    {
        char *s = KEYPAD_Input_Get();

        if(s)
        {
            if(s[0]=='\0')
                return false;

            float v;

            if(parse_float(s,&v))
            {
                *out = v;
                return true;
            }

            lcd_two_lines("Invalid","Try Again");
            HAL_Delay(800);

            I2C_LCD_Clear(LCD);
            I2C_LCD_SetCursor(LCD,0,0);
            I2C_LCD_WriteString(LCD,(char*)title);
        }

        HAL_Delay(LOOP_SLEEP_MS);
    }
}

/*--------------------------------------------------*/
/* Integer Prompt */
/*--------------------------------------------------*/

static bool prompt_uint(const char *title,uint32_t *out)
{
    float v;

    if(!prompt_float(title,&v))
        return false;

    if(v < 0)
        return false;

    *out = (uint32_t)v;

    return true;
}

/*--------------------------------------------------*/
/* Axis Move and Wait */
/*--------------------------------------------------*/

static HAL_StatusTypeDef move_and_wait(LinearAxis_t *axis,float target)
{
    HAL_StatusTypeDef st;

    st = Axis_MoveAbsolute(axis,target);

    if(st != HAL_OK)
        return st;

    while(AccelStepper_Run(axis->stepper))
    {
        HAL_Delay(5);
    }

    return HAL_OK;
}

/*--------------------------------------------------*/
/* Cycle Progress Display */
/*--------------------------------------------------*/

static void show_cycle_progress(uint32_t cycle,uint32_t total)
{
    char l1[17];
    char l2[17];

    snprintf(l1,sizeof(l1),"Cycle %lu/%lu",cycle,total);
    snprintf(l2,sizeof(l2),"Running...");

    lcd_two_lines(l1,l2);
}

/*--------------------------------------------------*/
/* Test Results Display */
/*--------------------------------------------------*/

static void show_results(float accuracy,float hyst,float repeat)
{
    char l1[17];
    char l2[17];

    snprintf(l1,sizeof(l1),"Accuracy:%4.1f%%",accuracy);
    snprintf(l2,sizeof(l2),"Hyster:%4.1f%%",hyst);

    lcd_two_lines(l1,l2);

    HAL_Delay(2500);

    snprintf(l1,sizeof(l1),"Repeat:%4.1f%%",repeat);
    lcd_two_lines(l1,"Test Done");

    HAL_Delay(2500);
}

/*--------------------------------------------------*/
/* Cyclic Test */
/*--------------------------------------------------*/

CyclicTestResult Cyclic_Test_Run(LinearAxis_t *axis,
                                 CyclicTestParams_t *params)
{
    if(!axis || !Axis_IsHomed(axis))
    {
        lcd_two_lines("Axis NOT Homed","Abort");
        HAL_Delay(1500);
        return CYCLIC_TEST_ERROR;
    }

    /* Declare 'p' at the function level so it remains accessible everywhere */
        CyclicTestParams_t p = {0};

        if (params != NULL)
        {
            p = *params; /* Copy incoming parameters if available */
        }

        /*--------------------------------------------------*/
        /* Step 1 : Set Null Position                       */
        /*--------------------------------------------------*/

        float null_mm = 0.0f;

        if (params != NULL && params->null_machine_mm > 0.0f)
        {
            null_mm = params->null_machine_mm;   /* use shared value */
            p.null_machine_mm = null_mm;
        }
        else
        {
            lcd_two_lines("Set NULL Pos","Press Enter");

            if(Null_SetNewReference(axis, &null_mm) != NULL_SET_OK)
                return CYCLIC_TEST_ABORTED;

            p.null_machine_mm = null_mm;
        }

    /*--------------------------------------------------*/
    /* Step 2 : User Inputs */
    /*--------------------------------------------------*/

    if(!prompt_float("Stroke(mm)",&p.stroke_range_mm))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_float("Null Volt(mV)",&p.null_voltage_mv))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_float("Sens(mV/V/mm)",&p.sensitivity_mv_v_mm))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_float("Exc Volt(V)",&p.excitation_voltage_v))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_float("Req Acc(%)",&p.required_accuracy_percent))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_float("Null Disp(mm)",&p.null_displacement_mm))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_float("Max Disp(+)",&p.max_displacement_mm))
        return CYCLIC_TEST_ABORTED;

    if(!prompt_uint("Cycles",&p.cycle_count))
        return CYCLIC_TEST_ABORTED;

    /*--------------------------------------------------*/
    /* Step 3 : Compute Motion Limits */
    /*--------------------------------------------------*/

    float start = p.null_machine_mm - p.stroke_range_mm;
    float end   = p.null_machine_mm + p.stroke_range_mm;

    if(start < AXIS_MIN_MM)
        start = AXIS_MIN_MM;

    if(end > AXIS_MAX_MM)
        end = AXIS_MAX_MM;

    /*--------------------------------------------------*/
    /* Step 4 : Move To Start Position */
    /*--------------------------------------------------*/

    lcd_two_lines("Moving Axis","To Start");

    if(move_and_wait(axis,start) != HAL_OK)
        return CYCLIC_TEST_ERROR;

    HAL_Delay(800);

    /*--------------------------------------------------*/
    /* Step 5 : Run Cyclic Test */
    /*--------------------------------------------------*/

    for(uint32_t i=1;i<=p.cycle_count;i++)
    {
        show_cycle_progress(i,p.cycle_count);

        if(move_and_wait(axis,end) != HAL_OK)
            return CYCLIC_TEST_ERROR;

        if(move_and_wait(axis,start) != HAL_OK)
            return CYCLIC_TEST_ERROR;
    }

    /*--------------------------------------------------*/
    /* Step 6 : Compute Results (Placeholder) */
    /*--------------------------------------------------*/

    float accuracy = 1.2f;
    float hysteresis = 0.8f;
    float repeatability = 0.5f;

    /*--------------------------------------------------*/
    /* Step 7 : Show Results */
    /*--------------------------------------------------*/

    show_results(accuracy,hysteresis,repeatability);

    /*--------------------------------------------------*/
    /* Step 8 : Return Axis Home */
    /*--------------------------------------------------*/

    lcd_two_lines("Returning","Home");

    move_and_wait(axis,AXIS_MIN_MM);

    if(params)
        *params = p;

    lcd_two_lines("Test Complete","Ready");

    HAL_Delay(1500);

    return CYCLIC_TEST_OK;
}
