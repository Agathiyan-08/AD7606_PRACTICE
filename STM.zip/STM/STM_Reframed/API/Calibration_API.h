/*
 * Calibration_API.h
 *
 *  Created on: Mar 17, 2026
 *      Author: Admin
 */

#ifndef CALIBRATION_API_H_
#define CALIBRATION_API_H_

#include "../ECUAL/Linear_Axis/linear_axis.h"
#include "../ECUAL/Limit_Switch/Limit_Switch_Driver.h"
#include "../API/motion/Stepper_Motion_Profile_API.h"

/* Calibration travel distance */
#define CALIBRATION_TRAVEL_MM   400.0f

typedef enum
{
    CALIB_IDLE = 0,
    CALIB_MOVE_FORWARD,
    CALIB_MOVE_REVERSE,
    CALIB_WAIT_HOME,
    CALIB_DONE
} CalibrationState_t;

typedef struct
{
    LinearAxis_t *axis;
    AccelStepper_Handle_t *stepper;

    CalibrationState_t state;

} Calibration_t;

/* API */
void Calibration_Init(Calibration_t *cal, LinearAxis_t *axis, AccelStepper_Handle_t *stepper);
void Calibration_Start(Calibration_t *cal);
void Calibration_Task(Calibration_t *cal,AccelStepper_Handle_t *stepper);

uint8_t Calibration_IsDone(Calibration_t *cal);


#endif /* CALIBRATION_API_H_ */
