/*
 * linear_axis.h
 *
 *  Created on: Mar 6, 2026
 *      Author: Admin
 */
#ifndef LINEAR_AXIS_H_
#define LINEAR_AXIS_H_

#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "../../API/MOTION/Stepper_Motion_Profile_API.h"
#include "ballscrew_config.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef struct
{
    /* Motion engine */
    AccelStepper_Handle_t *stepper;

    /* Machine limits (mm) */
    float soft_limit_min_mm;
    float soft_limit_max_mm;

    /* Home position (mm) */
    float home_pos_mm;

    /* State flags */
    bool is_homed;

} LinearAxis_t;


/* -------- Initialization -------- */

void Axis_Init(LinearAxis_t *axis,AccelStepper_Handle_t *stepper);


/* -------- Motion Commands -------- */

HAL_StatusTypeDef Axis_MoveAbsolute(LinearAxis_t *axis, float target_mm);

HAL_StatusTypeDef Axis_MoveRelative(LinearAxis_t *axis, float delta_mm);

HAL_StatusTypeDef Axis_MoveToHome(LinearAxis_t *axis);

HAL_StatusTypeDef Axis_Stop(LinearAxis_t *axis);

HAL_StatusTypeDef Axis_EmergencyStop(LinearAxis_t *axis);


/* -------- Axis Configuration -------- */

HAL_StatusTypeDef Axis_SetSoftLimits(LinearAxis_t *axis,float min_mm,float max_mm);

void Axis_SetHomePosition(LinearAxis_t *axis, float home_mm);

/* -------- Status / Query -------- */

float Axis_GetPosition_mm(LinearAxis_t *axis);

float Axis_GetTarget_mm(LinearAxis_t *axis);

bool Axis_IsHomed(LinearAxis_t *axis);

bool Axis_IsMoving(LinearAxis_t *axis);


#ifdef __cplusplus
}
#endif

#endif /* LINEAR_AXIS_H_ */
