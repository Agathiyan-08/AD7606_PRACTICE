/*
 * Null_Process_API.c
 *
 *  Created on: Mar 11, 2026
 *      Author: Admin
 */

#include "Null_Process_API.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "User_Input_API.h"

// ----- External keypad state from your driver -----
extern uint8_t KeyStates[16];
extern uint8_t prevKeyStates[16];
//extern void KEYPAD_Scan(uint16_t cols); // from your KEYPAD driver

// Key matrix mapping (declared in your keypad module)
#ifndef ROWS
#define ROWS 4
#endif
#ifndef COLS
#define COLS 4
#endif
extern const char KeyMap[ROWS][COLS];

// ----- Constants -----
#define LCD I2C_LCD_1
#define STEP_MM_BURST   (0.05f)      // 50 microns per burst
#define AXIS_MIN_MM     (0.0f)
#define AXIS_MAX_MM     (500.0f)
#define LOOP_SLEEP_MS   (5)          // UI loop tick



/* Wait until motion engine is fully idle; returns false on timeout */
static bool wait_motion_idle(LinearAxis_t *axis, uint32_t timeout_ms)
{
    uint32_t start = HAL_GetTick();

    while (Axis_IsMoving(axis))
    {
        AccelStepper_Run(axis->stepper);

        if ((HAL_GetTick() - start) > timeout_ms)
        {
            Axis_Stop(axis);
            return false;
        }
    }
    return true;
}

// ----- Utilities -----

static inline float clampf(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

// Convert matrix index to key char
static inline char key_from_index(int i) {
    int row = i / COLS;
    int col = i % COLS;
    return KeyMap[row][col];
}

// Poll one rising-edge key. Returns 0 if none.
static char keypad_poll_edge(void)
{
    char pressed = 0;
    KEYPAD_Scan(0);

    for (int i = 0; i < 16; i++) {
        if (KeyStates[i] == KEY_PRESSED && prevKeyStates[i] == KEY_RELEASED) {
            HAL_Delay(20); // debounce
            KEYPAD_Scan(0);
            if (KeyStates[i] == KEY_PRESSED) {
                pressed = key_from_index(i);
                // Don't break immediately; still update prev for all keys below.
            }
        }
        prevKeyStates[i] = KeyStates[i];
    }
    return pressed;
}

// Check if a specific key is currently held down.
static bool keypad_is_held(char key)
{
    KEYPAD_Scan(0);
    for (int i = 0; i < 16; i++) {
        if (KeyStates[i] == KEY_PRESSED) {
            if (key_from_index(i) == key) {
                return true;
            }
        }
    }
    return false;
}

// Wait until a specific key is released (to avoid immediate re-trigger).
static void keypad_wait_release(char key)
{
    while (keypad_is_held(key)) {
        HAL_Delay(LOOP_SLEEP_MS);
    }
}

// LCD helpers
static void lcd_two_lines(const char* l1, const char* l2)
{
    I2C_LCD_Clear(LCD);
    I2C_LCD_SetCursor(LCD, 0, 0);
    I2C_LCD_WriteString(LCD, (char*)l1);
    I2C_LCD_SetCursor(LCD, 0, 1);
    I2C_LCD_WriteString(LCD, (char*)l2);
}

// Move absolute with clamping; returns HAL status.
static HAL_StatusTypeDef move_absolute_clamped(LinearAxis_t *axis, float target_mm)
{
    target_mm = clampf(target_mm, AXIS_MIN_MM, AXIS_MAX_MM);
    return Axis_MoveAbsolute(axis, target_mm);
}

// Single burst jog: +step for 'U', -step for 'D'
static HAL_StatusTypeDef jog_burst(LinearAxis_t *axis, char key)
{
    float delta = 0.0f;
    if (key == 'U') delta = +STEP_MM_BURST;
    else if (key == 'D') delta = -STEP_MM_BURST;
    else return HAL_OK;

    // Clamp so we don't command outside limits
    float cur = Axis_GetPosition_mm(axis);
    float target = clampf(cur + delta, AXIS_MIN_MM, AXIS_MAX_MM);
    float commanded = target - cur;

    if (fabsf(commanded) < 1e-6f) {
        return HAL_OK; // already at limit
    }
    return Axis_MoveRelative(axis, commanded);
}

/* Repeated burst loop while a key is held.
 * Critical: AccelStepper_Run() must be called until the move finishes,
 * otherwise the motor never generates steps and position becomes wrong.
 */
static void jog_while_held(LinearAxis_t *axis, char heldKey)
{
    if (!keypad_is_held(heldKey))
    {
        return;
    }

    while (keypad_is_held(heldKey))
    {
        (void)jog_burst(axis, heldKey);
        (void)wait_motion_idle(axis, 2000U);
        HAL_Delay(5);
    }
}
// Try to parse a float safely from a C-string; returns true if parsed.
static bool parse_float(const char* s, float *out)
{
    if (!s) return false;
    // Trim spaces
    while (*s == ' ') s++;
    if (*s == '\0') return false;

    char *endp = NULL;
    float v = strtof(s, &endp);
    if (endp == s) return false; // no digits
    *out = v;
    return true;
}

// Manual absolute input prompt; returns:
//  - true and writes *outTarget when user entered mm and pressed E
//  - false when user chose Back (by pressing C then E -> empty input)
static bool manual_get_absolute_mm(float *outTarget)
{
    I2C_LCD_Clear(LCD);
    I2C_LCD_SetCursor(LCD, 0, 0);
    I2C_LCD_WriteString(LCD, "Pos(mm):");
    I2C_LCD_SetCursor(LCD, 0, 1);
    I2C_LCD_WriteString(LCD, "E=Move C:Back");

    I2C_LCD_SetCursor(LCD, 8U, 0U);


    // We rely on your KEYPAD_Input_Get() to echo chars to LCD line 0.
    // Back method: user presses 'C' to clear, then presses 'E' -> empty string => Back.
    while (1) {
        char *s = KEYPAD_Input_Get();
        if (s) {
            // If empty -> treat as Back
            if (s[0] == '\0') {
                return false; // back to menu
            }
            float v = 0.0f;
            if (parse_float(s, &v)) {
                *outTarget = clampf(v, AXIS_MIN_MM, AXIS_MAX_MM);
                return true;
            } else {
                lcd_two_lines("Invalid number", "Try again...");
                HAL_Delay(700);
                // Repaint prompt
                I2C_LCD_Clear(LCD);
                I2C_LCD_SetCursor(LCD, 0, 0);
                I2C_LCD_WriteString(LCD, "Pos(mm):");
                I2C_LCD_SetCursor(LCD, 0, 1);
                I2C_LCD_WriteString(LCD, "E=Move C:Back");
            }
        }
        HAL_Delay(LOOP_SLEEP_MS);
    }
}

// Jog mode screen loop.
// Returns true if user pressed E (confirm), false if C (back).
static bool jog_mode_loop(LinearAxis_t *axis)
{
    lcd_two_lines("Jog U:+ D:-", "E=OK  C=Back");

    while (1) {
        char k = keypad_poll_edge();
        if (k == 'E') {
            return true;  // proceed to confirm
        } else if (k == 'C') {
            return false; // back to top
        } else if (k == 'U' || k == 'D') {
            // While held, burst move
            jog_while_held(axis, k);
            // After release, stay in jog screen
            // Update bottom line with current pos (optional)
            char line2[17];
            float p = Axis_GetPosition_mm(axis);
            snprintf(line2, sizeof(line2), "Pos:%6.2fmm", p);
            I2C_LCD_SetCursor(LCD, 0, 1);
            I2C_LCD_WriteString(LCD, line2);
            // Restore tail text if overwritten
            // (Keep it simple due to 16-char constraints)
        }
        HAL_Delay(LOOP_SLEEP_MS);
    }
}

// Confirm screen loop: allow U/D jog & E confirm or C back.
// Returns: true if confirmed (E), false if back (C).
static bool confirm_null_loop(LinearAxis_t *axis)
{
    while (1) {
        // Show current position & prompt
        float p = Axis_GetPosition_mm(axis);
        char l1[17], l2[17];
        snprintf(l1, sizeof(l1), "Pos:%6.2fmm", p);
        snprintf(l2, sizeof(l2), "Null? E=YES");
        I2C_LCD_Clear(LCD);
        I2C_LCD_SetCursor(LCD, 0, 0);
        I2C_LCD_WriteString(LCD, l1);
        I2C_LCD_SetCursor(LCD, 0, 1);
        I2C_LCD_WriteString(LCD, "U/D:Jog C:Back");

        // Inner interaction
        while (1) {
            char k = keypad_poll_edge();
            if (k == 'E') {
                return true; // confirmed
            } else if (k == 'C') {
                return false; // back
            } else if (k == 'U' || k == 'D') {
                jog_while_held(axis, k);
                break; // break to repaint with new position
            }
            HAL_Delay(LOOP_SLEEP_MS);
        }
    }
}

// ----- Public API -----

NullSetResult Null_SetNewReference(LinearAxis_t *axis, float *outNullPosMm)
{
    if (!axis || !axis->is_homed) {
        lcd_two_lines("Axis NOT homed", "Abort");
        HAL_Delay(1000);
        return NULL_SET_ERROR;
    }

    // Top menu
    while (1) {
        lcd_two_lines("Null: U=Manual", "D=Jog  C=Exit");

        // Wait for a selection
        char k = 0;
        while ((k = keypad_poll_edge()) == 0) {
            HAL_Delay(LOOP_SLEEP_MS);
        }

        if (k == 'C') {
            // Exit whole function, no changes
            lcd_two_lines("Null cancelled", "");
            HAL_Delay(400);
            return NULL_SET_ABORTED;
        }
        else if (k == 'U') {
            // Manual absolute entry loop
        	I2C_LCD_Clear(I2C_LCD_1);
        	I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
        	I2C_LCD_WriteString(I2C_LCD_1, "Manual Mode");

        	HAL_Delay(1000);

            while (1) {
                float target = 0.0f;
                bool haveTarget = manual_get_absolute_mm(&target);
                if (!haveTarget) {
                    // Back to top
                    break;
                }
                /* ===== Robust absolute move ===== */

                /* 1. Kill any old command / jog residue */
                Axis_Stop(axis);
                (void)wait_motion_idle(axis, 500U);

                /* 2. Show the new absolute target */
                {
                    char l1[17];
                    snprintf(l1, sizeof(l1), "Move to %6.2f", target);
                    lcd_two_lines(l1, "Please wait...");
                }

                /* 3. Command absolute target (not relative) */
                if (move_absolute_clamped(axis, target) != HAL_OK)
                {
                    lcd_two_lines("Move rejected", "Check limits");
                    HAL_Delay(800);
                    break;
                }

                /* 4. Run until fully stopped at new target */
                if (!wait_motion_idle(axis, 30000U))
                {
                    lcd_two_lines("Move timeout", "Check axis");
                    HAL_Delay(800);
                    break;
                }

                /* 5. Show actual position (must match target) */
                {
                    float reached = Axis_GetPosition_mm(axis);
                    char buf[17];
                    snprintf(buf, sizeof(buf), "At:%6.2f mm", reached);
                    lcd_two_lines(buf, "Continue...");
                    HAL_Delay(600);
                }

                /* ===== End robust absolute move ===== */

                /* Ask for confirmation; allow fine jog & back */
                bool confirmed = confirm_null_loop(axis);
                if (confirmed) {
                    float pos = Axis_GetPosition_mm(axis);
                    if (outNullPosMm) *outNullPosMm = pos;

                    // NOTE: We DO NOT re-zero the global axis here.
                    // This keeps your 0..500 mm machine coordinate system intact
                    // for homing and other moves.
                    //
                    // OPTIONAL (if you ever change your mind):
                    // AccelStepper_SetCurrentPosition(axis->stepper, 0);

                    lcd_two_lines("Null saved at", "machine coords");
                    HAL_Delay(600);
                    return NULL_SET_OK;
                }
                // else back to manual input to try another absolute
            }
        }
        else if (k == 'D') {
            // Jog mode (burst while held)
            bool goConfirm = jog_mode_loop(axis);
            if (goConfirm) {
                bool confirmed = confirm_null_loop(axis);
                if (confirmed) {
                    float pos = Axis_GetPosition_mm(axis);
                    if (outNullPosMm) *outNullPosMm = pos;
                    lcd_two_lines("Null saved at", "machine coords");
                    HAL_Delay(600);
                    return NULL_SET_OK;
                }
                // else back to top menu
            }
        }
        else {
            // Ignore other keys at top
        }
    }
}
