/*
 * AD76061.h
 *
 *  Created on: Oct 28, 2026
 *      Author: Lenovo
 */

#ifndef AD7606_AD7606_H_
#define AD7606_AD7606_H_

// Private includes
#include <main.h>

extern SPI_HandleTypeDef hspi3;

// Variables
extern int16_t Reading_req[8];
extern float voltages[8];

// Function prototypes
void ADC_Reset(void);

void ADC_Init(void);

HAL_StatusTypeDef ADC_ReadData(int16_t *output_channels);

void Volt_Conv(void);

uint8_t Is_ADC_Connected(void);

#endif /* AD7606_AD7606_H_ */
