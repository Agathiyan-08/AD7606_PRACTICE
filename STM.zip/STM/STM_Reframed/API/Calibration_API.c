/*
 * Calibration_API.c
 *
 *  Created on: Mar 17, 2026
 *      Author: Admin
 */



#include "../ECUAL/Limit_Switch/Limit_Switch_Driver.h"
#include "../ECUAL/Linear_Axis/ballscrew_config.h"
#include "../API/Calibration_API.h"
#include "../ECUAL/I2C_LCD/I2C_LCD.h"

/* -------------------------------------------------- */

void Calibration_Init(Calibration_t *cal,
                      LinearAxis_t *axis,
                      AccelStepper_Handle_t *stepper)
{
    cal->axis = axis;
    cal->stepper = stepper;
    cal->state = CALIB_IDLE;
}

/* -------------------------------------------------- */

void Calibration_Start(Calibration_t *cal)
{
    cal->state = CALIB_MOVE_FORWARD;

    /* LCD Display */
    I2C_LCD_Clear(I2C_LCD_1);
    I2C_LCD_SetCursor(I2C_LCD_1,0,0);
    I2C_LCD_WriteString(I2C_LCD_1,"CALIBRATION");
    I2C_LCD_SetCursor(I2C_LCD_1,0,1);
    I2C_LCD_WriteString(I2C_LCD_1,"STARTED");

    HAL_Delay(5000);

    /* Show forward motion */
    I2C_LCD_Clear(I2C_LCD_1);
    I2C_LCD_SetCursor(I2C_LCD_1,0,0);
    I2C_LCD_WriteString(I2C_LCD_1,"MOVE FORWARD");
    /* Move from 0 -> 400mm */
    Axis_MoveAbsolute(cal->axis, CALIBRATION_TRAVEL_MM);

}

/* -------------------------------------------------- */

void Calibration_Task(Calibration_t *cal,AccelStepper_Handle_t *stepper)
{
    switch(cal->state)
    {

        /* -------------------------------------------------- */
        case CALIB_MOVE_FORWARD:

            if(!AccelStepper_IsRunning(cal->stepper))
            {
                /* Reached 400 mm -> move back */


                Axis_MoveAbsolute(cal->axis, 0.0f);
                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_SetCursor(I2C_LCD_1,0,0);
                I2C_LCD_WriteString(I2C_LCD_1,"MOVE REVERSE");

                cal->state = CALIB_MOVE_REVERSE;

            }

        break;

        /* -------------------------------------------------- */

        case CALIB_MOVE_REVERSE:


            if(!AccelStepper_IsRunning(cal->stepper))
            {

                cal->state = CALIB_WAIT_HOME;
            }

        break;

        /* -------------------------------------------------- */

        case CALIB_WAIT_HOME:

            if(LimitSwitch_ReadDebounced())
            {
                /* Stop motor */
                AccelStepper_Stop(cal->stepper);

                /* Reset axis position */
                cal->stepper->current_pos = 0.0f;


                /* LCD message */
                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_SetCursor(I2C_LCD_1,0,0);
                I2C_LCD_WriteString(I2C_LCD_1,"CALIBRATION");
                I2C_LCD_SetCursor(I2C_LCD_1,0,1);
                I2C_LCD_WriteString(I2C_LCD_1,"COMPLETED");

                cal->state = CALIB_DONE;
            }

        break;

        /* -------------------------------------------------- */

        case CALIB_DONE:
        case CALIB_IDLE:
        default:
        break;
    }
}

/* -------------------------------------------------- */

uint8_t Calibration_IsDone(Calibration_t *cal)
{
    return (cal->state == CALIB_DONE);
}
