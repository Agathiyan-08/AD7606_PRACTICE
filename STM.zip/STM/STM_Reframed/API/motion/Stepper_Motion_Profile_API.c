/*
 *
 *  AccelStepper-style non-blocking stepper motor driver for STM32.
 *  Pure GPIO — no timer peripheral required.
 *
 * ─── HOW THE SPEED/ACCEL ALGORITHM WORKS ────────────────────────────────────
 *
 *  At any instant the motor has a current_speed (steps/sec).
 *  Each time Run() fires a step, it recomputes current_speed by asking:
 *  "given my current speed and acceleration, what speed should I be at
 *   for the next step?"
 *
 *  The key formula (from kinematics v^2 = v0^2 + 2*a*d, d=1 step):
 *
 *    new_speed = sqrt(current_speed^2 + 2 * acceleration * direction)
 *
 *  Where direction = +1 if accelerating, -1 if decelerating.
 *
 *  The motor decelerates when:
 *    distance_to_go <= stopping_distance
 *    stopping_distance = current_speed^2 / (2 * acceleration)
 *
 *  This means SetMaxSpeed() and SetAcceleration() changes take effect
 *  on the very next step — immediately, mid-move.
 *
 * ─── TIMING ──────────────────────────────────────────────────────────────────
 *
 *  Uses DWT->CYCCNT for microsecond precision timing.
 *  step_interval_us = 1,000,000 / current_speed
 *  Run() fires a step when (now - last_step_time) >= step_interval_us
 */

#include "Stepper_Motion_Profile_API.h"
#include <math.h>
#include <stdlib.h>

/* =========================================================================
 * PRIVATE CONSTANTS
 * ========================================================================= */

/* Time consumed inside Stepper_Step(): 5µs HIGH + 5µs LOW = 10µs */
#define PULSE_TIME_US           10.0f

/* Absolute minimum step interval — prevents GPIO from being toggled
 * faster than STM32 can reliably handle (~20µs = 50,000 steps/sec max) */
#define MIN_STEP_INTERVAL_US    20.0f

/* Maximum step interval — limits slowest start speed (~2 steps/sec) */
#define MAX_STEP_INTERVAL_US    500000.0f

/* =========================================================================
 * PRIVATE: DWT MICROSECOND TIMER
 * ========================================================================= */

static void prv_dwt_init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT  = 0;
    DWT->CTRL   |= DWT_CTRL_CYCCNTENA_Msk;
}

static inline uint32_t prv_get_us(void)
{
    return DWT->CYCCNT / (SystemCoreClock / 1000000U);
}

/* =========================================================================
 * PRIVATE: CORE HELPERS
 * ========================================================================= */

/**
 * @brief  Recompute cached values whenever max_speed or acceleration changes.
 */
static void prv_recompute(AccelStepper_Handle_t *h)
{
    if (h->max_speed > 0.0f) {
        h->min_step_interval_us = 1000000.0f / h->max_speed;
        if (h->min_step_interval_us < MIN_STEP_INTERVAL_US)
            h->min_step_interval_us = MIN_STEP_INTERVAL_US;
    }
    if (h->acceleration > 0.0f) {
        h->sqrt_2a = sqrtf(2.0f * h->acceleration);
    }
}

/**
 * @brief  Compute stopping distance in steps from current speed.
 *         d = v^2 / (2 * a)
 */
static int32_t prv_stopping_distance(AccelStepper_Handle_t *h)
{
    if (h->acceleration <= 0.0f || h->current_speed == 0.0f) return 0;
    float d = (h->current_speed * h->current_speed) / (2.0f * h->acceleration);
    return (int32_t)(d + 1.0f);   /* +1 = always round up for safety */
}

/**
 * @brief  Compute the next step interval based on current speed and direction.
 *         Updates h->current_speed and h->step_interval_us.
 *         Called after every step.
 */
static void prv_compute_new_speed(AccelStepper_Handle_t *h)
{
    int32_t distance = h->target_pos - h->current_pos;   /* signed */
    int32_t abs_dist = abs(distance);
    int32_t stop_dist = prv_stopping_distance(h);

    if (abs_dist == 0) {
        /* Already at target */
        h->current_speed    = 0.0f;
        h->step_interval_us = 0.0f;
        h->running          = false;
        return;
    }

    /* Decide whether to accelerate or decelerate */
    bool should_decel = (abs_dist <= stop_dist);

    float new_speed;

    if (should_decel) {
        /* Decelerate: v_new = sqrt(v^2 - 2*a*1) — one step worth of decel */
        float v2 = h->current_speed * h->current_speed
                   - 2.0f * h->acceleration;
        if (v2 <= 0.0f) {
            /* Speed would go to zero or negative — clamp to minimum */
            new_speed = h->sqrt_2a;   /* One step of accel from rest */
        } else {
            new_speed = sqrtf(v2);
        }
    } else {
        /* Accelerate: v_new = sqrt(v^2 + 2*a*1) */
        float v2 = h->current_speed * h->current_speed
                   + 2.0f * h->acceleration;
        new_speed = sqrtf(v2);
    }

    /* Clamp to max_speed */
    if (new_speed > h->max_speed)
        new_speed = h->max_speed;

    /* Safety floor */
    if (new_speed < h->sqrt_2a)
        new_speed = h->sqrt_2a;

    h->current_speed = new_speed;

    /* Convert speed to step interval in µs */
    h->step_interval_us = 1000000.0f / new_speed;

    /* Clamp interval */
    if (h->step_interval_us < MIN_STEP_INTERVAL_US)
        h->step_interval_us = MIN_STEP_INTERVAL_US;
    if (h->step_interval_us > MAX_STEP_INTERVAL_US)
        h->step_interval_us = MAX_STEP_INTERVAL_US;

    /* Subtract the pulse time already consumed by Stepper_Step() */
    float wait = h->step_interval_us - PULSE_TIME_US;
    if (wait < MIN_STEP_INTERVAL_US) wait = MIN_STEP_INTERVAL_US;
    h->step_interval_us = wait;
}

/**
 * @brief  Set direction pin and update internal direction field.
 */
static void prv_set_direction(AccelStepper_Handle_t *h, int8_t dir)
{
    h->direction = dir;
    if (dir > 0) {
        Stepper_SetDirection(h->hw, STEPPER_DIR_CCW);
    } else {
        Stepper_SetDirection(h->hw, STEPPER_DIR_CW);
    }
    /* T60 requires DIR stable for 5µs before first PUL — use 10µs */
    delay_us(10);
}

/* =========================================================================
 * PUBLIC API IMPLEMENTATION
 * ========================================================================= */

void AccelStepper_Init(AccelStepper_Handle_t *h, Stepper_HandleTypeDef *hw)
{
    if (h == NULL || hw == NULL) return;

    /* Zero everything */
    h->hw                  = hw;
    h->max_speed           = 1000.0f;    /* Safe default: 1000 steps/sec  */
    h->acceleration        = 500.0f;     /* Safe default: 500 steps/sec^2 */
    h->current_pos         = 0;
    h->target_pos          = 0;
    h->current_speed       = 0.0f;
    h->step_interval_us    = 0.0f;
    h->last_step_time_us   = 0;
    h->direction           = 1;
    h->enabled             = false;
    h->running             = false;
    h->on_target_reached   = NULL;

    prv_dwt_init();
    prv_recompute(h);
}

/* -------------------------------------------------------------------------- */

void AccelStepper_SetMaxSpeed(AccelStepper_Handle_t *h, float speed)
{
    if (h == NULL || speed <= 0.0f) return;
    h->max_speed = speed;
    prv_recompute(h);
    /* If currently running, recompute next step interval immediately */
    if (h->running) {
        prv_compute_new_speed(h);
    }
}

/* -------------------------------------------------------------------------- */

void AccelStepper_SetAcceleration(AccelStepper_Handle_t *h, float accel)
{
    if (h == NULL || accel <= 0.0f) return;
    h->acceleration = accel;
    prv_recompute(h);
    if (h->running) {
        prv_compute_new_speed(h);
    }
}

/* -------------------------------------------------------------------------- */

void AccelStepper_MoveTo(AccelStepper_Handle_t *h, int32_t pos)
{
    if (h == NULL) return;

    if (h->target_pos == pos) return;   /* Already targeting this position */

    h->target_pos = pos;

    /* Set direction based on which way we need to go */
    int32_t distance = pos - h->current_pos;
    if (distance != 0) {
        int8_t new_dir = (distance > 0) ? 1 : -1;
        if (new_dir != h->direction) {
            prv_set_direction(h, new_dir);
        }
        h->running = true;

        /* If starting from rest, set initial slow speed */
        if (h->current_speed == 0.0f) {
            /* First step speed = sqrt(2 * a * 1 step) */
            h->current_speed    = h->sqrt_2a;
            h->step_interval_us = (1000000.0f / h->current_speed) - PULSE_TIME_US;
            if (h->step_interval_us < MIN_STEP_INTERVAL_US)
                h->step_interval_us = MIN_STEP_INTERVAL_US;
            h->last_step_time_us = prv_get_us();
        } else {
            /* Already moving — recompute for new target */
            prv_compute_new_speed(h);
        }
    }
}

/* -------------------------------------------------------------------------- */

void AccelStepper_Move(AccelStepper_Handle_t *h, int32_t steps)
{
    if (h == NULL) return;
    AccelStepper_MoveTo(h, h->current_pos + steps);
}

/* -------------------------------------------------------------------------- */

bool AccelStepper_Run(AccelStepper_Handle_t *h)
{
    if (h == NULL)      return false;
    if (!h->running)    return false;

    /* Check if target reached */
    if (h->current_pos == h->target_pos) {
        h->running       = false;
        h->current_speed = 0.0f;
        if (h->on_target_reached != NULL) {
            h->on_target_reached();
        }
        return false;
    }

    /* Check if enough time has elapsed for next step */
    uint32_t now = prv_get_us();
    uint32_t elapsed = now - h->last_step_time_us;

    if (elapsed < (uint32_t)h->step_interval_us) {
        return true;   /* Not yet time — return without blocking */
    }

    /* Time for next step — snapshot timestamp */
    h->last_step_time_us = now;

    /* Correct direction if needed (e.g. after mid-move target change) */
    int32_t distance = h->target_pos - h->current_pos;
    int8_t  needed_dir = (distance > 0) ? 1 : -1;
    if (needed_dir != h->direction) {
        prv_set_direction(h, needed_dir);
        /* After direction change, reset speed to slow start */
        h->current_speed    = h->sqrt_2a;
        h->step_interval_us = (1000000.0f / h->current_speed) - PULSE_TIME_US;
        if (h->step_interval_us < MIN_STEP_INTERVAL_US)
            h->step_interval_us = MIN_STEP_INTERVAL_US;
        return true;
    }

    /* Fire one step */
    Stepper_Step(h->hw);

    /* Update position */
    h->current_pos += h->direction;

    /* Recompute speed for next step based on new position and target */
    prv_compute_new_speed(h);

    return (h->current_pos != h->target_pos);
}

/* -------------------------------------------------------------------------- */

void AccelStepper_RunToPosition(AccelStepper_Handle_t *h)
{
    if (h == NULL) return;
    while (AccelStepper_Run(h));   /* Blocking — calls Run until done */
}

/* -------------------------------------------------------------------------- */

void AccelStepper_RunToNewPosition(AccelStepper_Handle_t *h, int32_t pos)
{
    if (h == NULL) return;
    AccelStepper_MoveTo(h, pos);
    AccelStepper_RunToPosition(h);
}

/* -------------------------------------------------------------------------- */

void AccelStepper_Stop(AccelStepper_Handle_t *h)
{
    if (h == NULL) return;
    /* Immediate stop — cut movement, may miss steps */
    h->target_pos    = h->current_pos;
    h->current_speed = 0.0f;
    h->running       = false;
}

/* -------------------------------------------------------------------------- */

void AccelStepper_StopSmooth(AccelStepper_Handle_t *h)
{
    if (h == NULL) return;
    if (!h->running || h->current_speed == 0.0f) return;

    /* Calculate minimum stopping distance from current speed */
    int32_t stop_dist = prv_stopping_distance(h);

    /* Set target to stop_dist steps ahead in current direction */
    h->target_pos = h->current_pos + (h->direction * stop_dist);
}

/* -------------------------------------------------------------------------- */

void AccelStepper_Enable(AccelStepper_Handle_t *h)
{
    if (h == NULL) return;
    Stepper_Enable(h->hw);
    h->enabled = true;
    delay_us(100);   /* Let T60 driver wake up */
}

/* -------------------------------------------------------------------------- */

void AccelStepper_Disable(AccelStepper_Handle_t *h)
{
    if (h == NULL) return;
    /* Stop motion first */
    h->running       = false;
    h->current_speed = 0.0f;
    Stepper_Disable(h->hw);
    h->enabled = false;
}

/* -------------------------------------------------------------------------- */

int32_t AccelStepper_CurrentPosition(AccelStepper_Handle_t *h)
{
    if (h == NULL) return 0;
    return h->current_pos;
}

/* -------------------------------------------------------------------------- */

int32_t AccelStepper_DistanceToGo(AccelStepper_Handle_t *h)
{
    if (h == NULL) return 0;
    return h->target_pos - h->current_pos;
}

/* -------------------------------------------------------------------------- */

int32_t AccelStepper_TargetPosition(AccelStepper_Handle_t *h)
{
    if (h == NULL) return 0;
    return h->target_pos;
}

/* -------------------------------------------------------------------------- */

float AccelStepper_CurrentSpeed(AccelStepper_Handle_t *h)
{
    if (h == NULL) return 0.0f;
    return h->current_speed;
}

/* -------------------------------------------------------------------------- */

void AccelStepper_SetCurrentPosition(AccelStepper_Handle_t *h, int32_t pos)
{
    if (h == NULL) return;
    h->current_pos = pos;
    h->target_pos  = pos;
    h->running     = false;
    h->current_speed = 0.0f;
}

/* -------------------------------------------------------------------------- */

bool AccelStepper_IsRunning(AccelStepper_Handle_t *h)
{
    if (h == NULL) return false;
    return h->running;
}

/* -------------------------------------------------------------------------- */

void AccelStepper_RegisterTargetCallback(AccelStepper_Handle_t *h,
                                          void (*cb)(void))
{
    if (h == NULL) return;
    h->on_target_reached = cb;
}
