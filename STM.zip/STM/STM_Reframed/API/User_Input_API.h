#ifndef USER_INPUT_API_H
#define USER_INPUT_API_H

#define KEYPAD_INPUT_MAX_LEN 20

void KEYPAD_Input_Init(void);
char* KEYPAD_Input_Get(void);

#endif
