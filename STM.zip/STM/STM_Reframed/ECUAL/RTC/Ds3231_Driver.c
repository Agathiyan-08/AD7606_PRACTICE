#include "Ds3231_Driver.h"

// ================= PRIVATE DEFINES =================
#define DS3231_ADDRESS 0xD0

// ================= PRIVATE VARIABLES =================
static I2C_HandleTypeDef *ds3231_i2c;

// ================= PRIVATE FUNCTIONS =================

// Decimal to BCD
static uint8_t decToBcd(int val)
{
    return (uint8_t)((val / 10 * 16) + (val % 10));
}

// BCD to Decimal
static int bcdToDec(uint8_t val)
{
    return (int)((val / 16 * 10) + (val % 16));
}

// ================= PUBLIC FUNCTIONS =================

// Initialize
void DS3231_Init(I2C_HandleTypeDef *hi2c)
{
    ds3231_i2c = hi2c;
}

// Set Time
void DS3231_SetTime(DS3231_Time *time)
{
    uint8_t set_time[7];

    set_time[0] = decToBcd(time->seconds);
    set_time[1] = decToBcd(time->minutes);
    set_time[2] = decToBcd(time->hour);
    set_time[3] = decToBcd(time->dayofweek);
    set_time[4] = decToBcd(time->dayofmonth);
    set_time[5] = decToBcd(time->month);
    set_time[6] = decToBcd(time->year);

    HAL_I2C_Mem_Write(ds3231_i2c, DS3231_ADDRESS, 0x00, 1, set_time, 7, 1000);
}

// Get Time
void DS3231_GetTime(DS3231_Time *time)
{
    uint8_t get_time[7];

    HAL_I2C_Mem_Read(ds3231_i2c, DS3231_ADDRESS, 0x00, 1, get_time, 7, 1000);

    time->seconds     = bcdToDec(get_time[0]);
    time->minutes     = bcdToDec(get_time[1]);
    time->hour        = bcdToDec(get_time[2]);
    time->dayofweek   = bcdToDec(get_time[3]);
    time->dayofmonth  = bcdToDec(get_time[4]);
    time->month       = bcdToDec(get_time[5]);
    time->year        = bcdToDec(get_time[6]);
}

// Get Temperature
float DS3231_GetTemperature(void)
{
    uint8_t temp[2];

    HAL_I2C_Mem_Read(ds3231_i2c, DS3231_ADDRESS, 0x11, 1, temp, 2, 1000);

    return (temp[0] + ((temp[1] >> 6) / 4.0));
}

// Force Temperature Conversion
void DS3231_ForceTemperature(void)
{
    uint8_t status = 0;
    uint8_t control = 0;

    // Read status register
    HAL_I2C_Mem_Read(ds3231_i2c, DS3231_ADDRESS, 0x0F, 1, &status, 1, 100);

    // Check BSY bit
    if (!(status & 0x04))
    {
        // Read control register
        HAL_I2C_Mem_Read(ds3231_i2c, DS3231_ADDRESS, 0x0E, 1, &control, 1, 100);

        // Set CONV bit
        control |= 0x20;

        HAL_I2C_Mem_Write(ds3231_i2c, DS3231_ADDRESS, 0x0E, 1, &control, 1, 100);
    }
}
