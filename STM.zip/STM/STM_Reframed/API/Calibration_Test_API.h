
/*
 * Calibration_Test_API.h
 *
 *  Created on: 2026
 *      Author: Admin
 *
 *  @brief  LVDT Calibration Test API — STM32F446RE
 *
 *  Overview:
 *    - User inputs: Stroke Range (mm), Excitation Voltage (V),
 *                  Operational Displacement (mm)
 *    - Exactly 11 displacement points entered manually via keypad
 *    - For each point: motor moves to (null + displacement), ADC reads
 *      LVDT output voltage, sensitivity and linearity are computed
 *    - After all 11 points: best-fit slope (LSQ regression) is computed
 *    - Full results logged to SD card as CSV: CALIB_YYYYMMDD.CSV
 *
 *  Dependencies:
 *    - LinearAxis API     (linear_axis.h)
 *    - AccelStepper API   (AccelStepper_STM32.h)
 *    - Null Process API   (Null_Process_API.h)
 *    - I2C LCD API        (I2C_LCD.h)
 *    - Keypad API         (KEYPAD.h)
 *    - DS3231 RTC API     (ds3231.h)
 *    - FatFS              (fatfs.h / ff.h)
 *    - ADC:               Fill in the TODO stub in Calibration_Test_API.c
 */

#ifndef CALIBRATION_TEST_API_H_
#define CALIBRATION_TEST_API_H_

#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"
#include "../../ECUAL/KEYPAD/KEYPAD.h"
#include "../../API/Null_Process_API.h"
#include "../../ECUAL/RTC/Ds3231_Driver.h"
#include "fatfs.h"
#include "../../ECUAL/Linear_Axis/linear_axis.h"

#ifdef __cplusplus
extern "C" {
#endif

/* =========================================================================
 * CONFIGURATION
 * ========================================================================= */

#define CALIB_NUM_POINTS        11      /**< Fixed number of calibration points         */
#define CALIB_LCD_IDX           0       /**< I2C_LCD instance index (I2C_LCD_1 = 0)     */
#define CALIB_INPUT_BUF_LEN     10      /**< Max chars for a keypad numeric entry        */
#define CALIB_LCD_RESULT_DELAY  3000    /**< ms to show a result screen before moving on */
#define CALIB_LCD_MSG_DELAY     1500    /**< ms for short status messages               */

/* =========================================================================
 * DATA STRUCTURES
 * ========================================================================= */

/**
 * @brief  User-supplied test parameters entered once at session start.
 */
typedef struct
{
    float stroke_range_mm;          /**< Full mechanical stroke range of LVDT (mm)  */
    float excitation_voltage_v;     /**< AC/DC excitation voltage applied to LVDT (V)*/
    float operational_disp_mm;      /**< Rated operational displacement (mm)         */
} CalibTestParams_t;

/**
 * @brief  Data recorded for one calibration point.
 */
typedef struct
{
    float  displacement_mm;         /**< Displacement entered by user (mm), relative to null */
    float  output_voltage_v;        /**< LVDT output voltage from ADC (V)                    */
    float  sensitivity_v_mm_v;      /**< Sensitivity in V / mm / V (excitation)              */
    float  sensitivity_mv_v_mm;     /**< Sensitivity in mV / V / mm                          */
    float  linearity_pct;           /**< Linearity: (measured / ideal) * 100 - 100  (%)      */
} CalibPoint_t;

/**
 * @brief  Summary computed after all 11 points are collected.
 */
typedef struct
{
    float  best_fit_slope;          /**< LSQ regression slope          (V/mm)   */
    float  best_fit_intercept;      /**< LSQ regression intercept      (V)      */
    float  max_linearity_error_pct; /**< Peak linearity deviation       (%)     */
    float  avg_sensitivity_mv_v_mm; /**< Mean sensitivity across points (mV/V/mm)*/
} CalibSummary_t;

/**
 * @brief  Full calibration session handle.
 *         Caller declares one instance and passes its pointer to CalibTest_Run().
 */
typedef struct
{
    CalibTestParams_t   params;                     /**< User-entered parameters            */
    CalibPoint_t        points[CALIB_NUM_POINTS];   /**< Per-point measured data            */
    CalibSummary_t      summary;                    /**< Computed after all 11 points       */
    uint8_t             points_collected;           /**< Running count of recorded points   */
    float               null_pos_mm;               /**< Machine-coordinate null position    */
    DS3231_Time         timestamp;                  /**< RTC snapshot at session start       */
} CalibTestSession_t;

/**
 * @brief  Return codes used by all Calibration Test API functions.
 */
typedef enum
{
    CALIB_OK            = 0,    /**< Operation completed successfully           */
    CALIB_ABORTED       = 1,    /**< User pressed Cancel ('C') at a prompt      */
    CALIB_MOTION_ERROR  = 2,    /**< Axis motion command returned HAL_ERROR     */
    CALIB_SD_ERROR      = 3,    /**< SD card / FatFS mount or write failed      */
    CALIB_INPUT_ERROR   = 4,    /**< Numeric input out of range or malformed    */
    CALIB_NULL_ERROR    = 5,    /**< Null process failed or was aborted         */
} CalibResult_t;

/* =========================================================================
 * PUBLIC API
 * ========================================================================= */

/**
 * @brief  Top-level entry point. Call from your main menu.
 *
 *  Full internal sequence:
 *    1. Capture RTC timestamp (for CSV filename).
 *    2. Prompt user to enter 3 test parameters via keypad.
 *    3. Run Null process — establishes reference zero (null_pos_mm).
 *    4. Loop for CALIB_NUM_POINTS (11) iterations:
 *         a. Prompt: "Point N/11 — Enter displacement (mm):"
 *         b. Read signed float from keypad (range-checked vs stroke_range_mm).
 *         c. Move axis to (null_pos_mm + displacement_mm).
 *         d. Read ADC voltage via TODO stub.
 *         e. Compute sensitivity and linearity for this point.
 *         f. Display results on LCD.
 *         g. Wait for user to press '#' to proceed to next point.
 *    5. Compute best-fit line slope + full summary.
 *    6. Display summary on LCD.
 *    7. Write CSV file to SD card.
 *    8. Return axis to null position.
 *
 * @param  axis   Pointer to an initialized and homed LinearAxis_t handle.
 * @return CalibResult_t
 */
CalibResult_t CalibTest_Run(LinearAxis_t *axis,
                            float         pre_null_mm,
                            bool          null_is_valid);
/**
 * @brief  Step 2 — Prompt user to enter the 3 test parameters via keypad.
 *
 *  Screen sequence:
 *    Screen 1: "Stroke Range(mm):"   → read positive float
 *    Screen 2: "Excitation V (V):"   → read positive float
 *    Screen 3: "Oper Disp (mm):"     → read positive float
 *
 *  'C' at any screen aborts the entire test.
 *
 * @param  session  Session handle; params field filled on CALIB_OK.
 * @return CALIB_OK or CALIB_ABORTED
 */
CalibResult_t CalibTest_EnterParams(CalibTestSession_t *session);

/**
 * @brief  Step 3 — Run the Null process; store result in session->null_pos_mm.
 *
 * @param  axis     Pointer to LinearAxis handle.
 * @param  session  Session handle; null_pos_mm written on CALIB_OK.
 * @return CALIB_OK, CALIB_NULL_ERROR, or CALIB_ABORTED
 */
CalibResult_t CalibTest_SetNull(LinearAxis_t       *axis,
                                CalibTestSession_t *session,
                                float               pre_null_mm,
                                bool                null_is_valid);
/**
 * @brief  Step 4 — Collect one calibration data point.
 *
 *  Performs the full sub-sequence (4a–4g) for a single point.
 *  Called by CalibTest_Run() in a for-loop.
 *
 * @param  axis       Pointer to LinearAxis handle.
 * @param  session    Session handle.
 * @param  point_idx  Index 0..10 indicating which point is being collected.
 * @return CALIB_OK, CALIB_ABORTED, CALIB_MOTION_ERROR, or CALIB_INPUT_ERROR
 */
CalibResult_t CalibTest_CollectPoint(LinearAxis_t       *axis,
                                     CalibTestSession_t *session,
                                     uint8_t             point_idx);

/**
 * @brief  Step 5 — Compute summary from all 11 collected points.
 *
 *  Fills session->summary:
 *    - best_fit_slope and best_fit_intercept via least-squares regression
 *      (x = displacement_mm, y = output_voltage_v)
 *    - max_linearity_error_pct — peak |linearity_pct| across all points
 *    - avg_sensitivity_mv_v_mm — arithmetic mean of all 11 sensitivity values
 *
 * @param  session  Session handle with all CALIB_NUM_POINTS points populated.
 */
void CalibTest_ComputeSummary(CalibTestSession_t *session);

/**
 * @brief  Step 6 — Cycle through summary result screens on the LCD.
 *
 *  Screen 1: Best-fit slope (V/mm) and intercept (V)
 *  Screen 2: Max linearity error (%)
 *  Screen 3: Average sensitivity (mV/V/mm)
 *  Each screen is shown for CALIB_LCD_RESULT_DELAY ms.
 *
 * @param  session  Fully populated session handle.
 */
void CalibTest_DisplaySummary(const CalibTestSession_t *session);

/**
 * @brief  Step 7 — Write full calibration data to CSV on the SD card.
 *
 *  Filename derived from session->timestamp: CALIB_YYYYMMDD.CSV
 *
 *  CSV format:
 *  ---- Header rows ----
 *  Calibration Test Report
 *  Date,DD/MM/YY
 *  Stroke Range (mm),<value>
 *  Excitation Voltage (V),<value>
 *  Operational Displacement (mm),<value>
 *  Null Position (mm),<value>
 *  ---- Column headers ----
 *  Point,Displacement(mm),Output Voltage(V),Sensitivity(V/mm/V),Sensitivity(mV/V/mm),Linearity(%)
 *  ---- 11 data rows ----
 *  1,...
 *  ...
 *  ---- Summary rows ----
 *  Best-Fit Slope (V/mm),<value>
 *  Best-Fit Intercept (V),<value>
 *  Max Linearity Error (%),<value>
 *  Avg Sensitivity (mV/V/mm),<value>
 *
 * @param  session  Fully populated session handle.
 * @return CALIB_OK or CALIB_SD_ERROR
 */
CalibResult_t CalibTest_WriteCSV(const CalibTestSession_t *session);

/* =========================================================================
 * UTILITY / HELPERS  (internal use — exposed for testability)
 * ========================================================================= */

/**
 * @brief  Read a signed or unsigned float from the keypad.
 *
 *  Key map:
 *    '0'..'9'  → digit
 *    '.'       → decimal point (only one allowed)
 *    '-'       → negative sign (only at index 0, only if allow_neg == true)
 *    '*'       → backspace (delete last char)
 *    '#'       → confirm / Enter
 *    'C'       → cancel / abort → returns CALIB_ABORTED
 *
 *  The function blocks until '#' or 'C' is pressed.
 *  The current input string is echoed on LCD row 1.
 *
 * @param  out_value  [OUT] Parsed float value (valid only on CALIB_OK).
 * @param  allow_neg  Pass true to permit a leading '-'.
 * @return CALIB_OK or CALIB_ABORTED
 */
CalibResult_t CalibTest_KeypadReadFloat(float *out_value, bool allow_neg);

/**
 * @brief  Build the CSV filename from a DS3231_Time struct.
 *         Output: "CALIB_YYYYMMDD.CSV"  (null-terminated)
 *
 * @param  buf  Destination buffer — must be at least 20 bytes.
 * @param  t    Pointer to DS3231_Time (year is 2-digit; 2000 is added internally).
 */
void CalibTest_BuildFilename(char *buf, size_t buf_size,
                             const DS3231_Time *t);

/**
 * @brief  Compute least-squares linear regression over n (x, y) pairs.
 *
 *  Used internally by CalibTest_ComputeSummary() with:
 *    x[] = displacement_mm[]
 *    y[] = output_voltage_v[]
 *
 * @param  x              Array of n x-values.
 * @param  y              Array of n y-values.
 * @param  n              Number of data points.
 * @param  out_slope      [OUT] Regression slope.
 * @param  out_intercept  [OUT] Regression intercept.
 */
void CalibTest_LinearRegression(const float *x, const float *y, uint8_t n,
                                float *out_slope, float *out_intercept);

#ifdef __cplusplus
}
#endif

#endif /* CALIBRATION_TEST_API_H_ */
