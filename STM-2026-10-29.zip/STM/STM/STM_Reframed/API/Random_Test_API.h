/*
 * Random_Test_API.h
 *
 *  Created on: Mar 12, 2026
 *      Author: Admin
 *
 * Random_Test_API.h
 *
 *  Random LVDT Test UI for STM32F446RE
 *  Uses:
 *    - Null_SetNewReference() to capture LVDT null in machine mm
 *    - KEYPAD_Input_Get() for numeric/user input
 *    - I2C LCD for UI
 *    - LinearAxis (AccelStepper) for motion
 *
 *  Pre-conditions:
 *    - Axis homed, Axis_SetSoftLimits(axis, 0, 500) succeeded
 *    - Stepper speed/accel configured elsewhere
 *
 */

#ifndef RANDOM_TEST_API_H_
#define RANDOM_TEST_API_H_

#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "main.h"
#include "../../ECUAL/Linear_Axis/linear_axis.h"
#include "../API/Null_Process_API.h"   // adjust include path if different
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"
#include "../../API/USER_INPUT_API.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    float stroke_range_mm;        // ±mm window around Null (requested)
    float excitation_voltage_v;   // stored only
    float op_displacement_mm;     // stored only
    bool  null_is_valid;      /* true = null_machine_mm already set in main */

    // Captured/derived
    float null_machine_mm;        // machine mm returned by Null process
    float logical_min_mm;         // clamped window min in machine mm
    float logical_max_mm;         // clamped window max in machine mm
} RandomTestParams_t;

typedef enum {
    RANDOM_TEST_OK = 0,
    RANDOM_TEST_ABORTED,
    RANDOM_TEST_ERROR
} RandomTestResult;

/**
 * @brief  Run the interactive Random Test flow.
 *
 * Steps:
 *  1) Run Null_SetNewReference() to capture LVDT Null in machine mm.
 *  2) Prompt user for Stroke(±mm), Excitation(V), Op.Displacement(mm).
 *  3) Compute logical window [Null-±Stroke] clamped to [0..500].
 *  4) Offer modes: U=Manual (type relative mm), R=Random (auto targets), C=Exit.
 *  5) Move to each target; LCD shows progress & position each step.
 *
 * @param  axis        Linear axis handle (must be homed & limits set).
 * @param  ioParams    [IN/OUT] If non-NULL: initial values are used as defaults,
 *                     and final values are written back on success.
 * @return RandomTestResult
 *
 */


RandomTestResult Random_Test_Run(LinearAxis_t *axis, RandomTestParams_t *ioParams);

#ifdef __cplusplus
}
#endif

#endif /* RANDOM_TEST_API_H_ */
