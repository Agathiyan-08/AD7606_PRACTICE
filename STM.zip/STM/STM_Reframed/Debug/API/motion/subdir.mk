################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../API/motion/Stepper_Motion_Profile_API.c 

OBJS += \
./API/motion/Stepper_Motion_Profile_API.o 

C_DEPS += \
./API/motion/Stepper_Motion_Profile_API.d 


# Each subdirectory must supply rules for building sources it contributes
API/motion/%.o API/motion/%.su API/motion/%.cyclo: ../API/motion/%.c API/motion/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-API-2f-motion

clean-API-2f-motion:
	-$(RM) ./API/motion/Stepper_Motion_Profile_API.cyclo ./API/motion/Stepper_Motion_Profile_API.d ./API/motion/Stepper_Motion_Profile_API.o ./API/motion/Stepper_Motion_Profile_API.su

.PHONY: clean-API-2f-motion

