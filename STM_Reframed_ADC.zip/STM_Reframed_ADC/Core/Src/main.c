/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "../../ECUAL/RTC/Ds3231_Driver.h"
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"
#include "../../ECUAL/KEYPAD/KEYPAD.h"
#include "../../ECUAL/STEPPER_MOTOR/Stepper_motor_API.h"
#include "../../ECUAL/STEPPER_MOTOR/Stepper_Config.h"
#include "../../ECUAL/Limit_Switch/Limit_Switch_Driver.h"
#include "../../API/Homing_API.h"
#include "../../API/motion/Stepper_Motion_Profile_API.h"
#include "../../ECUAL/Linear_Axis/ballscrew_config.h"
#include "../../ECUAL/Linear_Axis/linear_axis.h"
#include "../../API/Null_Process_API.h"
#include "../../API/Menu_API.h"
#include "../../API/Random_Test_API.h"
#include "../../API/Calibration_Test_API.h"
#include "../../API/Calibration_API.h"
#include "../../API/Cyclic_test_API.h"
#include "../../ECUAL/AD7606/ad7606.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* ----------------- Build-time config ----------------- */
#define APP_CALIB_TIMEOUT_MS      (60u * 1000u)   // 60s safety timeout
#define APP_MAIN_LOOP_PERIOD_MS   1u              // loop tick
/* Optional safety timeout */
#define CYCLIC_TIMEOUT_MS   60000U


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi2;
SPI_HandleTypeDef hspi3;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

Axis_HandleTypeDef  homeX;

/* Shared LVDT null position (machine coordinates mm) */
static float g_lvdt_null_mm   = 0.0f;
static bool  g_null_is_valid  = false;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI2_Init(void);
static void MX_SPI3_Init(void);
/* USER CODE BEGIN PFP */


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//Stepper_HandleTypeDef hstepper1;

void DWT_Init(void)
{
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	DWT->CYCCNT = 0;
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;


}
/*------------------------------LCD ---------------------------------------*/

char *inputData;
uint8_t KeyStates[16]       = {0};
uint8_t prevKeyStates[16]   = {0};

/*------------------------------LCD ---------------------------------------*/

/*------------------------------SD_card ---------------------------------------*/

char TxBuffer[250];
FATFS FatFs;
FIL Fil;
FRESULT FR_Status;
FATFS *FS_Ptr;
UINT RWC, WWC; // Read/Write Word Counter
DWORD FreeClusters;
uint32_t TotalSize, FreeSpace;
char RW_Buffer[200];

/*------------------------------SD_card ---------------------------------------*/

/*------------------------------ RTC ---------------------------------------*/

DS3231_Time rtc_time = {

		      .seconds = 0,
		      .minutes = 30,
		      .hour = 12,
		      .dayofweek = 1,
		      .dayofmonth = 28,
		      .month = 2,
		      .year = 26

               };

float temp;

/*------------------------------ RTC ---------------------------------------*/

/*------------------------------ Axis---------------------------------------*/
AccelStepper_Handle_t motor;
LinearAxis_t xAxis;
Calibration_t cal;
/*------------------------------ Axis---------------------------------------*/

//setter for the null
float Get_LVDT_null(void)
{
    return g_lvdt_null_mm;
}

bool Get_LVDT_boll(void)
{
    return g_null_is_valid;
}

/* Internal helper */
static bool wait_until_reached(LinearAxis_t *axis, uint32_t timeout_ms)
{
    uint32_t start = HAL_GetTick();

    while (Axis_IsMoving(axis))
    {
        /* Run stepper motion (VERY IMPORTANT) */
        AccelStepper_Run(&motor);

        if ((HAL_GetTick() - start) > timeout_ms)
        {
            return false;  // timeout
        }
    }

    return true;
}

void OnTargetReached(void)
{
    // Optional callback when target reached
}

void app_run_random_test(LinearAxis_t *axis)
{
	RandomTestParams_t params = {
	        .stroke_range_mm      = 25.0f,
	        .excitation_voltage_v = 0.0f,
	        .op_displacement_mm   = 0.0f,
	        .null_machine_mm      = g_lvdt_null_mm,
	        .null_is_valid        = g_null_is_valid   /* critical */
	    };

    RandomTestResult r = Random_Test_Run(&xAxis, &params);

    switch (r)
    {
        case RANDOM_TEST_OK:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_WriteString(I2C_LCD_1, "Random Test ");
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 1);
            I2C_LCD_WriteString(I2C_LCD_1, "Done");
            HAL_Delay(1000);
            break;

        case RANDOM_TEST_ABORTED:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_WriteString(I2C_LCD_1, "Random Test ");
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 1);
            I2C_LCD_WriteString(I2C_LCD_1, "Aborted"); //due to the operation displayment is zero
            HAL_Delay(1000);
            break;

        case RANDOM_TEST_ERROR:
        	if(g_lvdt_null_mm == 0.0f)
        	{
                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_WriteString(I2C_LCD_1, "Null @ starting");
                I2C_LCD_SetCursor(I2C_LCD_1, 0, 1);
                I2C_LCD_WriteString(I2C_LCD_1, "of the Axis");
                HAL_Delay(1000);
        	}
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_WriteString(I2C_LCD_1, "Random Test ");
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 1);
            I2C_LCD_WriteString(I2C_LCD_1, "Error");
            HAL_Delay(1000);
            break;
    }
}

void Do_Null_Setting(void)
{
    float null_mm = 0.0f;

    while(true)
    {
		NullSetResult r = Null_SetNewReference(&xAxis, &null_mm);

		if (r == NULL_SET_OK) {

			g_lvdt_null_mm = null_mm;
			g_null_is_valid = true;

			I2C_LCD_Clear(I2C_LCD_1);
			I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
			I2C_LCD_WriteString(I2C_LCD_1, "Repeat? (C/E)");
			I2C_LCD_SetCursor(I2C_LCD_1, 0U, 1U);
			I2C_LCD_WriteString(I2C_LCD_1, "C:Yes, Press E");


			bool exit_null = false;

			// Asking the user to repeat the Null process
			while(true)
			{
				char *input_str = KEYPAD_Input_Get();

				if (input_str != NULL)
				{
					// Directly compare the character
					if (input_str[0] == 'C')
					{
						exit_null = true; // User chose 'C' to exit
						break;
					}
					else if (input_str[0] == 'E' || input_str[0] == '\0')
					{
						exit_null = false; // User pressed 'E' to repeat
						break;
					}
					else
					{
						I2C_LCD_Clear(I2C_LCD_1);
						I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
						I2C_LCD_WriteString(I2C_LCD_1, "Invalid input!");
						HAL_Delay(1000);

						/* Redraw prompt */
						I2C_LCD_Clear(I2C_LCD_1);
						I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
						I2C_LCD_WriteString(I2C_LCD_1, "Repeat? (C/E)");
					}
				}

				HAL_Delay(5);
			}

			if (exit_null)
			{
				break; // Exit the main loop
			}

		} else if (r == NULL_SET_ABORTED) {
			break;

		} else {
			g_null_is_valid = false;
			I2C_LCD_Clear(I2C_LCD_1);
			I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
			I2C_LCD_WriteString(I2C_LCD_1, "Null Error");
			HAL_Delay(1000);
			break;
		}
	}

	I2C_LCD_Clear(I2C_LCD_1);
	I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
	I2C_LCD_WriteString(I2C_LCD_1, "Exiting Null");
	HAL_Delay(1000);
}

/* === Mock task handlers === */
static void Random_test(void)
{
    // Replace with your API calls
    I2C_LCD_Clear(I2C_LCD_1);
    I2C_LCD_WriteString(I2C_LCD_1, "Random Test...");
    HAL_Delay(1000);

    app_run_random_test(&xAxis);

}

static void Cyclic_Test(void)
{
    I2C_LCD_Clear(I2C_LCD_1);
    I2C_LCD_WriteString(I2C_LCD_1, "Cyclic Test...");
    HAL_Delay(1000);

    CyclicTestParams_t params =
        {
            .null_machine_mm = g_lvdt_null_mm,
            .stroke_range_mm = 20.0f,
            .null_voltage_mv = 0.0f,
            .sensitivity_mv_v_mm = 0.0f,
            .excitation_voltage_v = 0.0f,
            .required_accuracy_percent = 1.0f,
            .null_displacement_mm = 0.0f,
            .max_displacement_mm = 0.0f,
            .cycle_count = 10
        };

        CyclicTestResult r = Cyclic_Test_Run(&xAxis, &params);

        switch (r)
        {
            case CYCLIC_TEST_OK:
                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_WriteString(I2C_LCD_1, "Cyclic Done");
                break;

            case CYCLIC_TEST_ABORTED:
                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_WriteString(I2C_LCD_1, "Cyclic Abort");
                break;

            case CYCLIC_TEST_ERROR:
            default:
                I2C_LCD_Clear(I2C_LCD_1);
                I2C_LCD_WriteString(I2C_LCD_1, "Cyclic Error");
                break;
        }

        HAL_Delay(2000);

}

static void Calibration(void)
{
    I2C_LCD_Clear(I2C_LCD_1);
    I2C_LCD_WriteString(I2C_LCD_1, "Calibration...");
    HAL_Delay(1000);


    CalibResult_t result = CalibTest_Run(&xAxis,
                                             g_lvdt_null_mm,
                                             g_null_is_valid);

    switch (result)
    {
        case CALIB_OK:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "Calib Complete!");
            HAL_Delay(2000);
            break;

        case CALIB_ABORTED:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "Calib Aborted");
            HAL_Delay(2000);
            break;

        case CALIB_SD_ERROR:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "SD Card Error!");
            I2C_LCD_SetCursor(I2C_LCD_1, 1, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "Check SD card");
            HAL_Delay(2000);
            break;

        case CALIB_MOTION_ERROR:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "Motion Error!");
            I2C_LCD_SetCursor(I2C_LCD_1, 1, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "Check axis");
            HAL_Delay(2000);
            break;

        case CALIB_INPUT_ERROR:
        case CALIB_NULL_ERROR:
        default:
            I2C_LCD_Clear(I2C_LCD_1);
            I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
            I2C_LCD_WriteString(I2C_LCD_1, "Calib Error");
            HAL_Delay(2000);
            break;
    }

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_SPI2_Init();
  MX_FATFS_Init();
  MX_SPI3_Init();
  /* USER CODE BEGIN 2 */

  DWT_Init();
  Stepper_Config_Init();
  I2C_LCD_Init(I2C_LCD_1);
  KEYPAD_Init(0, KeyStates);
  DS3231_Init(&hi2c1);
  KEYPAD_Input_Init();
  ADC_Init();


 // ADC Connectivity Test
    if (Is_ADC_Connected() == 0U)
    {
        I2C_LCD_Clear(I2C_LCD_1);
        I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
        I2C_LCD_WriteString(I2C_LCD_1, "ADC Connected");
        I2C_LCD_SetCursor(I2C_LCD_1, 0U, 1U);
        I2C_LCD_WriteString(I2C_LCD_1, "AD7606 OK");
        HAL_Delay(1500U);
    }
    else
    {
        I2C_LCD_Clear(I2C_LCD_1);
        I2C_LCD_SetCursor(I2C_LCD_1, 0U, 0U);
        I2C_LCD_WriteString(I2C_LCD_1, "ADC Fail!");
        I2C_LCD_SetCursor(I2C_LCD_1, 0U, 1U);
        I2C_LCD_WriteString(I2C_LCD_1, "Check AD7606");
        HAL_Delay(2000U);
    }

   /* --- FatFS / SD card --- */
   if (f_mount(&FatFs, USERPath, 1) != FR_OK)
   {
       I2C_LCD_Clear(I2C_LCD_1);
       I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
       I2C_LCD_WriteString(I2C_LCD_1, "SD Mount Failed!");
       HAL_Delay(2000);
       /* Optionally halt or set a flag — calibration will still report
          CALIB_SD_ERROR gracefully when it tries to open the file.      */
   }
   if (f_mount(&FatFs, USERPath, 1) == FR_OK)
     {

         I2C_LCD_Clear(I2C_LCD_1);
         I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
         I2C_LCD_WriteString(I2C_LCD_1, "SD Mounted");
         HAL_Delay(2000);

         /* Optionally halt or set a flag — calibration will still report
            CALIB_SD_ERROR gracefully when it tries to open t      he file.      */
     }

	 DS3231_SetTime(&rtc_time);

     I2C_LCD_Clear(I2C_LCD_1);
     I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
     I2C_LCD_WriteString(I2C_LCD_1, "STM Project");

      HAL_Delay(3000);

      // Initialize limit switch (active high)

      I2C_LCD_Clear(I2C_LCD_1);
      I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
      I2C_LCD_WriteString(I2C_LCD_1, "LS_ENB");

      homeX.stepper = &hstepper1;
      homeX.position_mm = 0;

      Axis_Home(&homeX);

      I2C_LCD_Clear(I2C_LCD_1);
      I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
      I2C_LCD_WriteString(I2C_LCD_1, "HOMING completed");

      HAL_Delay(2000);

	  /* 2) Initialize AccelStepper motion on top of your GPIO stepper */
	  AccelStepper_Init(&motor, &hstepper1);
	  AccelStepper_RegisterTargetCallback(&motor, OnTargetReached);

	  /* 3) Power-up the driver when ready */
	  AccelStepper_Enable(&motor);

	  /* 4) Configure motion parameters (change anytime, take effect immediately) */
	  AccelStepper_SetMaxSpeed(&motor, 5000.0f);      // steps/sec
	  AccelStepper_SetAcceleration(&motor, 2500.0f);  // steps/sec^2

	  /* 5) Wrap in axis API (mm units + soft limits) */
	  Axis_Init(&xAxis, &motor);
	  Axis_SetSoftLimits(&xAxis, 0.0f, 500.0f);        // 0..100 mm travel

	  Axis_SetHomePosition(&xAxis, 0.0f);

	  /* Force motion engine position to 0 after physical homing */
	  AccelStepper_SetCurrentPosition(&motor, 0);

	  xAxis.is_homed = true;
//    Axis_MoveAbsolute(&xAxis, 20.0f);

	   Do_Null_Setting();

     	  /* Menu items (labels should be short to fit 16-char LCD) */
     	      const menu_item_t items[] = {
     	    		{ .number = '1', .label = "Rand", .action = Random_test },
     	    		{ .number = '2', .label = "Cyc",  .action = Cyclic_Test },
     	    		{ .number = '3', .label = "Cal",  .action = Calibration },
     	      };

     	      MENU_Init();            // LCD + keypad input init , (optional)
     	      MENU_Run(items, 3);     // blocks forever


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

//	  inputData = KEYPAD_Input_Get();
//	  if(inputData != 0)
//	  {
//	   // DATA READY HERE
//		  I2C_LCD_Clear(I2C_LCD_1);
//		  I2C_LCD_SetCursor(I2C_LCD_1, 0, 0);
//		  I2C_LCD_WriteString(I2C_LCD_1, "The Enter Value:");
//
//		  I2C_LCD_SetCursor(I2C_LCD_1, 1, 0);
//		  I2C_LCD_WriteString(I2C_LCD_1, inputData);
//
//		  HAL_Delay(1000);
//	  }

//	  AccelStepper_Run(&motor);  // returns quickly; no blocking

//	       	           // You can queue next commands when not moving:
//	       	           if (!Axis_IsMoving(&xAxis))
//	       	           {
//	       	               // Example sequence:
//	       	               Axis_MoveRelative(&xAxis, +10.0f);  // +10 mm
//	       	               while (Axis_IsMoving(&xAxis)) { AccelStepper_Run(&motor); }
//
//	       	               Axis_MoveAbsolute(&xAxis, 5.0f);    // back to 5 mm
//	       	               while (Axis_IsMoving(&xAxis)) { AccelStepper_Run(&motor); }
//
//	       	               // Smooth stop demo
//	       	               Axis_Stop(&xAxis);                  // decelerated stop if moving
//	       	               // Emergency stop demo (instant)
//	       	               // Axis_EmergencyStop(&xAxis);
//
//	       	               // Disable if you want to de-energize
//	       	               AccelStepper_Disable(&motor);
//
//	       	               // Done: park here
//
//	       	           }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 90;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief SPI3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI3_Init(void)
{

  /* USER CODE BEGIN SPI3_Init 0 */

  /* USER CODE END SPI3_Init 0 */

  /* USER CODE BEGIN SPI3_Init 1 */

  /* USER CODE END SPI3_Init 1 */
  /* SPI3 parameter configuration*/
  hspi3.Instance = SPI3;
  hspi3.Init.Mode = SPI_MODE_MASTER;
  hspi3.Init.Direction = SPI_DIRECTION_2LINES;
  hspi3.Init.DataSize = SPI_DATASIZE_16BIT;
  hspi3.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi3.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi3.Init.NSS = SPI_NSS_SOFT;
  hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi3.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI3_Init 2 */

  /* USER CODE END SPI3_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, SPI2_CS_Pin|ADC_CS_Pin|ADC_OS2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|ADC_OS0_Pin|ADC_OS1_Pin|ADC_RST_Pin
                          |C1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, C4_Pin|C3_Pin|C2_Pin|ADC_Range_Pin
                          |ADC_CVB_Pin|ADC_CVA_Pin|PUL_Pin|ENA_Pin
                          |DIR_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : SPI2_CS_Pin ADC_CS_Pin ADC_OS2_Pin */
  GPIO_InitStruct.Pin = SPI2_CS_Pin|ADC_CS_Pin|ADC_OS2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin ADC_OS0_Pin ADC_OS1_Pin ADC_RST_Pin
                           C1_Pin */
  GPIO_InitStruct.Pin = LD2_Pin|ADC_OS0_Pin|ADC_OS1_Pin|ADC_RST_Pin
                          |C1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ADC_Busy_Pin */
  GPIO_InitStruct.Pin = ADC_Busy_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ADC_Busy_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : R3_Pin R2_Pin R1_Pin */
  GPIO_InitStruct.Pin = R3_Pin|R2_Pin|R1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : C4_Pin C3_Pin C2_Pin ADC_Range_Pin
                           ADC_CVB_Pin ADC_CVA_Pin PUL_Pin ENA_Pin
                           DIR_Pin */
  GPIO_InitStruct.Pin = C4_Pin|C3_Pin|C2_Pin|ADC_Range_Pin
                          |ADC_CVB_Pin|ADC_CVA_Pin|PUL_Pin|ENA_Pin
                          |DIR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Limit_Pin_Pin */
  GPIO_InitStruct.Pin = Limit_Pin_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Limit_Pin_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : R4_Pin */
  GPIO_InitStruct.Pin = R4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(R4_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
