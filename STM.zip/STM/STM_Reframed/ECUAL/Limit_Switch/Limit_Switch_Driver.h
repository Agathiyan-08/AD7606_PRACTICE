#ifndef LIMIT_SWITCH_H
#define LIMIT_SWITCH_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* ---------------- CONFIGURATION ---------------- */

/* Change these according to your hardware */

#define LIMIT_SWITCH_PORT GPIOB
#define LIMIT_SWITCH_PIN  GPIO_PIN_15

/* Active state
   1 = active HIGH
   0 = active LOW
*/
#define LIMIT_SWITCH_ACTIVE_STATE 1

/* Debounce samples */
#define LIMIT_SWITCH_DEBOUNCE_COUNT 5

/* ------------------------------------------------ */

uint8_t LimitSwitch_Read(void);

uint8_t LimitSwitch_ReadDebounced(void);

#endif
