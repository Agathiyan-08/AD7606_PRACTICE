
#include "ad7606.h"



static HAL_StatusTypeDef AD7606_WaitBusyLow(void)
{
    uint32_t start = HAL_GetTick();

    while (HAL_GPIO_ReadPin(BUSY_PORT, BUSY_PIN) == GPIO_PIN_SET)
    {
        if ((HAL_GetTick() - start) >= AD7606_BUSY_TIMEOUT_MS)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

static HAL_StatusTypeDef AD7606_WaitBusyHigh(void)
{
    uint32_t start = HAL_GetTick();

    while (HAL_GPIO_ReadPin(BUSY_PORT, BUSY_PIN) == GPIO_PIN_RESET)
    {
        if ((HAL_GetTick() - start) >= AD7606_BUSY_TIMEOUT_MS)
        {
            return HAL_TIMEOUT;
        }
    }

    return HAL_OK;
}

/* ---------------- Control functions ---------------- */

void ConvAB_Init(void)
{
    HAL_GPIO_WritePin(CA_PORT, CA_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(CB_PORT, CB_PIN, GPIO_PIN_SET);
}

void ResetAD7606(void)
{
    CS_Di();

    HAL_GPIO_WritePin(CA_PORT, CA_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(CB_PORT, CB_PIN, GPIO_PIN_RESET);

    HAL_GPIO_WritePin(RESET_PORT, RESET_PIN, GPIO_PIN_RESET);
    HAL_Delay(1U);

    HAL_GPIO_WritePin(RESET_PORT, RESET_PIN, GPIO_PIN_SET);
    HAL_Delay(1U);

    HAL_GPIO_WritePin(RESET_PORT, RESET_PIN, GPIO_PIN_RESET);
    HAL_Delay(1U);

    ConvAB_Init();
}

void OverSamplingEn(uint8_t os)
{
    uint8_t bits;

    /*
     * OS[2:0]:
     * 000 = no oversampling
     * 001 = x2
     * 010 = x4
     * 011 = x8
     * 100 = x16
     * 101 = x32
     * 110 = x64
     */
    if (os > OVERSAMPLING64)
    {
        os = OVERSAMPLING0;
    }

    bits = os;

    HAL_GPIO_WritePin(OS0_PORT, OS0_PIN,
        (bits & 0x01U) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(OS1_PORT, OS1_PIN,
        (bits & 0x02U) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(OS2_PORT, OS2_PIN,
        (bits & 0x04U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void AD7606ConvStAB(void)
{
    /*
     * Both CONVST inputs are pulsed together.
     * Conversion starts on the rising edge.
     *
     * The 1 ms low pulse is deliberately conservative for
     * initial testing, not for high-speed acquisition.
     */
    HAL_GPIO_WritePin(CA_PORT, CA_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(CB_PORT, CB_PIN, GPIO_PIN_RESET);

    HAL_Delay(1U);

    HAL_GPIO_WritePin(CA_PORT, CA_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(CB_PORT, CB_PIN, GPIO_PIN_SET);
}

void CS_En(void)
{
    HAL_GPIO_WritePin(CS_PORT, CS_PIN, GPIO_PIN_RESET);
}

void CS_Di(void)
{
    HAL_GPIO_WritePin(CS_PORT, CS_PIN, GPIO_PIN_SET);
}

/* ---------------- Initialization ---------------- */

void AD7606_Init(void)
{
    CS_Di();

    /* RANGE LOW selects +/-5 V on the AD7606 */
    HAL_GPIO_WritePin(RANGE_PORT, RANGE_PIN, GPIO_PIN_RESET);

    ConvAB_Init();
    OverSamplingEn(OVERSAMPLING0);
    ResetAD7606();

    (void)AD7606_WaitBusyLow();
}

/* ---------------- ADC acquisition ---------------- */

HAL_StatusTypeDef AD7606_ADC(int16_t *adcRaw)
{
    uint8_t rx[RAW_DATA_BYTES];
    HAL_StatusTypeDef status;

    if (adcRaw == NULL)
    {
        return HAL_ERROR;
    }

    CS_Di();

    status = AD7606_WaitBusyLow();
    if (status != HAL_OK)
    {
        return status;
    }

    /*
     * Start conversion with CS inactive.
     */
    AD7606ConvStAB();

    /*
     * Wait for conversion to start and finish.
     */
    status = AD7606_WaitBusyHigh();
    if (status != HAL_OK)
    {
        CS_Di();
        return status;
    }

    status = AD7606_WaitBusyLow();
    if (status != HAL_OK)
    {
        CS_Di();
        return status;
    }

    /*
     * Read eight 16-bit results from one DOUT stream.
     * Requires SPI3 configured for 8-bit data size.
     */
    CS_En();

    status = HAL_SPI_Receive(&hspi3,
                            rx,
                            RAW_DATA_BYTES,
                            100U);

    CS_Di();

    if (status != HAL_OK)
    {
        return status;
    }

    for (uint32_t i = 0U; i < RAW_DATA_SIZE; i++)
    {
        uint16_t raw =
            ((uint16_t)rx[2U * i] << 8) |
             (uint16_t)rx[(2U * i) + 1U];

        adcRaw[i] = (int16_t)raw;
    }

    return HAL_OK;
}

/* ---------------- Raw-to-voltage conversion ---------------- */

void Data_Conv(float *voltage, const int16_t *adcRaw)
{
    if ((voltage == NULL) || (adcRaw == NULL))
    {
        return;
    }

    for (uint32_t i = 0U; i < RAW_DATA_SIZE; i++)
    {
        /*
         * Bipolar 16-bit conversion, nominal +/-5 V range.
         * Check/calibrate against your ADC board and reference.
         */
        voltage[i] =
            ((float)adcRaw[i] * AD7606_INPUT_RANGE_V) / 32768.0f;
    }
}

/* ---------------- Connectivity test ---------------- */

uint8_t AD7606_IsConnected(void)
{
    int16_t raw[RAW_DATA_SIZE];

    if (AD7606_ADC(raw) != HAL_OK)
    {
        return 1U;
    }

    /*
     * A successful SPI transaction and completed conversion
     * are the basic connectivity checks. A disconnected DOUT
     * can still produce constant data, so this is not a full
     * electrical self-test.
     */
    return 0U;
}
