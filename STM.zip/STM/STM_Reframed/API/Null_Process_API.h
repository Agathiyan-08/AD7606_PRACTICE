/*
 * Null_Process_API.h
 *
 *  Created on: Mar 11, 2026
 *      Author: Admin
 */

#ifndef NULL_PROCESS_API_H_
#define NULL_PROCESS_API_H_

#ifndef NULL_PROCESS_H_
#define NULL_PROCESS_H_

#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "../../ECUAL/I2C_LCD/I2C_LCD.h"
#include "../../API/USER_INPUT_API.h"
#include "../../ECUAL/KEYPAD/KEYPAD.h"
#include "../../ECUAL/Linear_Axis/linear_axis.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    NULL_SET_OK = 0,       // user confirmed null; outNullPosMm is valid
    NULL_SET_ABORTED = 1,  // user exited with C from top menu; no change
    NULL_SET_ERROR = 2     // invalid state or motion error
} NullSetResult;

/**
 * @brief Interactive Null (Set New Reference) process.
 *
 * Pre-conditions:
 *  - Axis homed.
 *  - Soft limits configured to 0..500 mm.
 *
 * Behavior:
 *  - U -> Manual absolute position entry (0..500 mm).
 *  - D -> Jog (hold U:+0.05, D:-0.05).
 *  - After positioning, confirm: "Null? E=YES"; U/D jog; C back.
 *
 * Result:
 *  - On confirm (E), returns NULL_SET_OK and writes current machine position (mm)
 *    into *outNullPosMm. The global Linear Axis zero is NOT changed.
 *
 * @param axis            Pointer to LinearAxis handle.
 * @param outNullPosMm    [OUT] Captured null position in machine mm (if OK).
 * @return NullSetResult
 */
NullSetResult Null_SetNewReference(LinearAxis_t *axis, float *outNullPosMm);

#ifdef __cplusplus
}
#endif

#endif /* NULL_PROCESS_H_ */

#endif /* NULL_PROCESS_API_H_ */
