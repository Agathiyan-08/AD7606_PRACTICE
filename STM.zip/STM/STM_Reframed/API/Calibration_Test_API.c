/*
 * Calibration_Test_API.c
 *
 *  Created on: Mar 17, 2026
 *      Author: Admin
 */
/*
 * Calibration_Test_API.c
 *
 *  Created on: 2026
 *      Author: Admin
 *
 *  Search for "TODO" to find the ADC stub you must fill in.
 */

#include "Calibration_Test_API.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* =========================================================================
 * TODO — ADC STUB
 *  Replace the return line with your actual ADC read function.
 *  Must return LVDT output voltage in Volts (float).
 *  e.g.:  return read_voltage_ad7606();
 * ========================================================================= */
static float CalibTest_ReadADC(void)
{
    /* TODO: return read_voltage_ad7606(); */
    return 0.0f;
}

/* =========================================================================
 * PRIVATE HELPER — write up to 2 lines to LCD
 * ========================================================================= */
static void LCD_ShowLines(const char *line1, const char *line2)
{
    I2C_LCD_Clear(CALIB_LCD_IDX);
    if (line1)
    {
        I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 0);
        I2C_LCD_WriteString(CALIB_LCD_IDX, (char *)line1);
    }
    if (line2)
    {
        I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
        I2C_LCD_WriteString(CALIB_LCD_IDX, (char *)line2);
    }
}

/* =========================================================================
 * CalibTest_KeypadReadFloat
 * ========================================================================= */
CalibResult_t CalibTest_KeypadReadFloat(float *out_value, bool allow_neg)
{
    char    buf[CALIB_INPUT_BUF_LEN + 1] = {0};
    uint8_t idx      = 0;
    bool    has_dot  = false;
    bool    has_sign = false;

    /* Clear row 1 */
    I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
    I2C_LCD_WriteString(CALIB_LCD_IDX, "                ");
    I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);

    while (1)
    {
        char *key = KEYPAD_Input_Get();
        if (!key) { HAL_Delay(50); continue; }

        if (key[0] == 'C') return CALIB_ABORTED;

        if (key[0] == '#')
        {
            uint8_t start = has_sign ? 1u : 0u;
            bool    ok    = false;
            for (uint8_t i = start; i < idx; i++)
                if (buf[i] >= '0' && buf[i] <= '9') { ok = true; break; }
            if (!ok) continue;
            *out_value = strtof(buf, NULL);
            return CALIB_OK;
        }

        if (key[0] == '*')
        {
            if (idx > 0)
            {
                idx--;
                if (buf[idx] == '.')             has_dot  = false;
                if (buf[idx] == '-')             has_sign = false;
                buf[idx] = '\0';
            }
            I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
            I2C_LCD_WriteString(CALIB_LCD_IDX, "                ");
            I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
            I2C_LCD_WriteString(CALIB_LCD_IDX, buf);
            HAL_Delay(100);
            continue;
        }

        if (key[0] == '-' && allow_neg && idx == 0 && !has_sign)
        {
            buf[idx++] = '-'; buf[idx] = '\0'; has_sign = true;
            I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
            I2C_LCD_WriteString(CALIB_LCD_IDX, buf);
            HAL_Delay(100); continue;
        }

        if (key[0] == '.' && !has_dot && idx < CALIB_INPUT_BUF_LEN)
        {
            buf[idx++] = '.'; buf[idx] = '\0'; has_dot = true;
            I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
            I2C_LCD_WriteString(CALIB_LCD_IDX, buf);
            HAL_Delay(100); continue;
        }

        if (key[0] >= '0' && key[0] <= '9' && idx < CALIB_INPUT_BUF_LEN)
        {
            buf[idx++] = key[0]; buf[idx] = '\0';
            I2C_LCD_SetCursor(CALIB_LCD_IDX, 0, 1);
            I2C_LCD_WriteString(CALIB_LCD_IDX, buf);
            HAL_Delay(100);
            continue;
        }

        HAL_Delay(50);
    }
}

/* =========================================================================
 * CalibTest_BuildFilename
 * ========================================================================= */


void CalibTest_BuildFilename(char *buf, size_t buf_size,
                             const DS3231_Time *t)
{
    if (buf == NULL || t == NULL || buf_size == 0u)
    {
        return;
    }

    unsigned yr = 2000u + (unsigned)t->year;

    snprintf(buf, buf_size, "CALIB_%04u%02u%02u.CSV",
             yr,
             (unsigned)t->month,
             (unsigned)t->dayofmonth);
}

/* =========================================================================
 * CalibTest_LinearRegression
 * ========================================================================= */
void CalibTest_LinearRegression(const float *x, const float *y, uint8_t n,
                                float *out_slope, float *out_intercept)
{
    if (n < 2u) { *out_slope = 0.0f; *out_intercept = 0.0f; return; }

    float sx = 0, sy = 0, sxx = 0, sxy = 0;
    for (uint8_t i = 0; i < n; i++)
    {
        sx  += x[i]; sy  += y[i];
        sxx += x[i] * x[i]; sxy += x[i] * y[i];
    }
    float denom = ((float)n * sxx) - (sx * sx);
    if (fabsf(denom) < 1e-9f)
    {
        *out_slope     = 0.0f;
        *out_intercept = sy / (float)n;
        return;
    }
    *out_slope     = (((float)n * sxy) - (sx * sy)) / denom;
    *out_intercept = (sy - (*out_slope * sx)) / (float)n;
}

/* =========================================================================
 * CalibTest_EnterParams
 * ========================================================================= */
CalibResult_t CalibTest_EnterParams(CalibTestSession_t *session)
{
    CalibResult_t res;
    float val = 0.0f;

    /* DO NOT put null here */

    LCD_ShowLines("Stroke Range(mm)", "");
    res = CalibTest_KeypadReadFloat(&val, false);
    if (res != CALIB_OK) return res;
    if (val <= 0.0f) {
        LCD_ShowLines("Invalid value!", NULL);
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return CALIB_INPUT_ERROR;
    }
    session->params.stroke_range_mm = val;

    LCD_ShowLines("Excitation V (V)", "");
    res = CalibTest_KeypadReadFloat(&val, false);
    if (res != CALIB_OK) return res;
    if (val <= 0.0f) {
        LCD_ShowLines("Invalid value!", NULL);
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return CALIB_INPUT_ERROR;
    }
    session->params.excitation_voltage_v = val;

    LCD_ShowLines("Oper Disp (mm)", "");
    res = CalibTest_KeypadReadFloat(&val, false);
    if (res != CALIB_OK) return res;
    if (val <= 0.0f) {
        LCD_ShowLines("Invalid value!", NULL);
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return CALIB_INPUT_ERROR;
    }
    session->params.operational_disp_mm = val;

    return CALIB_OK;
}

/* =========================================================================
 * CalibTest_SetNull
 * ========================================================================= */
CalibResult_t CalibTest_SetNull(LinearAxis_t       *axis,
                                CalibTestSession_t *session,
                                float               pre_null_mm,
                                bool                null_is_valid)
{
    if ((axis == NULL) || (session == NULL))
    {
        return CALIB_NULL_ERROR;
    }

    /* Null already done in main → reuse it (0.0 mm is allowed) */
    if (null_is_valid == true)
    {
        session->null_pos_mm = pre_null_mm;
        return CALIB_OK;
    }

    /* No valid null yet → ask operator */
    float null_mm = 0.0f;
    NullSetResult nr = Null_SetNewReference(axis, &null_mm);

    if (nr == NULL_SET_OK)
    {
        session->null_pos_mm = null_mm;
        return CALIB_OK;
    }
    if (nr == NULL_SET_ABORTED)
    {
        return CALIB_ABORTED;
    }

    return CALIB_NULL_ERROR;
}

/* =========================================================================
 * CalibTest_CollectPoint
 * ========================================================================= */
CalibResult_t CalibTest_CollectPoint(LinearAxis_t       *axis,
                                     CalibTestSession_t *session,
                                     uint8_t             point_idx)
{
    CalibResult_t res;
    char          l1[17], l2[17];
    float         disp_mm    = 0.0f;
    float         half_stroke = session->params.stroke_range_mm / 2.0f;

    /* 4a: Prompt displacement entry */
    //snprintf(l1, sizeof(l1), "Pt %02u/11 Disp mm", point_idx + 1u);
    snprintf(l1, sizeof(l1), "Point %u Disp",
             (unsigned)(point_idx + 1u));

    LCD_ShowLines(l1, "");
    res = CalibTest_KeypadReadFloat(&disp_mm, true);
    if (res != CALIB_OK) return res;

    /* Range check */
    if (disp_mm < -half_stroke || disp_mm > half_stroke)
    {
        LCD_ShowLines("Out of stroke", "range! Retry.");
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return CALIB_INPUT_ERROR;
    }

    /* 4c: Move axis */
    float target_mm = session->null_pos_mm + disp_mm;
    snprintf(l1, sizeof(l1), "Moving %.2fmm", disp_mm);
    LCD_ShowLines(l1, "Please wait...");

    if (Axis_MoveAbsolute(axis, target_mm) != HAL_OK)
    {
        LCD_ShowLines("Motion error!", "Check axis.");
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return CALIB_MOTION_ERROR;
    }
    while (Axis_IsMoving(axis)) { __NOP(); }
    HAL_Delay(100); /* ADC settle */

    /* 4d: Read ADC */
    float v_out = CalibTest_ReadADC();

    /* 4e: Compute sensitivity and linearity */
    float sens_v  = 0.0f, sens_mv = 0.0f, linearity = 0.0f;
    float exc_v   = session->params.excitation_voltage_v;
    float op_mm   = session->params.operational_disp_mm;

    if (exc_v > 0.0f && fabsf(disp_mm) > 1e-6f)
    {
        sens_v  = v_out / (exc_v * disp_mm);
        sens_mv = (v_out * 1000.0f) / (exc_v * disp_mm);
    }

    float full_scale_v = fabsf(sens_v) * exc_v * op_mm;
    if (full_scale_v > 1e-6f)
    {
        float ideal_v = sens_v * exc_v * disp_mm;
        linearity     = ((v_out - ideal_v) / full_scale_v) * 100.0f;
    }

    /* Store */
    CalibPoint_t *pt        = &session->points[point_idx];
    pt->displacement_mm     = disp_mm;
    pt->output_voltage_v    = v_out;
    pt->sensitivity_v_mm_v  = sens_v;
    pt->sensitivity_mv_v_mm = sens_mv;
    pt->linearity_pct       = linearity;
    session->points_collected = point_idx + 1u;

    /* 4f: Show result */
    snprintf(l1, sizeof(l1), "V=%.4fV S=%.2f",  v_out, sens_mv);
    snprintf(l2, sizeof(l2), "Lin=%.2f%%",       linearity);
    LCD_ShowLines(l1, l2);
    HAL_Delay(CALIB_LCD_RESULT_DELAY);

    /* 4g: Wait for '#' to proceed */
    LCD_ShowLines("# next  C abort", NULL);
    while (1)
    {
        char *k = KEYPAD_Input_Get();
        if (k[0] == '#') break;
        if (k[0] == 'C') return CALIB_ABORTED;
        HAL_Delay(50);
    }

    return CALIB_OK;
}

/* =========================================================================
 * CalibTest_ComputeSummary
 * ========================================================================= */
void CalibTest_ComputeSummary(CalibTestSession_t *session)
{
    uint8_t n = session->points_collected;
    float   x[CALIB_NUM_POINTS], y[CALIB_NUM_POINTS];
    float   sum_sens = 0.0f, max_err = 0.0f;

    for (uint8_t i = 0; i < n; i++)
    {
        x[i]      = session->points[i].displacement_mm;
        y[i]      = session->points[i].output_voltage_v;
        sum_sens += session->points[i].sensitivity_mv_v_mm;
        float e   = fabsf(session->points[i].linearity_pct);
        if (e > max_err) max_err = e;
    }

    CalibTest_LinearRegression(x, y, n,
                               &session->summary.best_fit_slope,
                               &session->summary.best_fit_intercept);

    session->summary.max_linearity_error_pct = max_err;
    session->summary.avg_sensitivity_mv_v_mm = (n > 0u) ? (sum_sens / (float)n) : 0.0f;
}

/* =========================================================================
 * CalibTest_DisplaySummary
 * ========================================================================= */

void CalibTest_DisplaySummary(const CalibTestSession_t *session)
{
    char l2[17];

    /* Display slope */
    LCD_ShowLines("Best-fit slope", "V/mm");
    HAL_Delay(1500);

    if (isfinite(session->summary.best_fit_slope) &&
        fabsf(session->summary.best_fit_slope) < 100.0f)
    {
        snprintf(l2, sizeof(l2), "%.3f",
                 (double)session->summary.best_fit_slope);
    }
    else
    {
        snprintf(l2, sizeof(l2), "Out of range");
    }

    LCD_ShowLines("Slope:", l2);
    HAL_Delay(CALIB_LCD_RESULT_DELAY);

    /* Display intercept */
    if (isfinite(session->summary.best_fit_intercept) &&
        fabsf(session->summary.best_fit_intercept) < 100.0f)
    {
        snprintf(l2, sizeof(l2), "%.3f",
                 (double)session->summary.best_fit_intercept);
    }
    else
    {
        snprintf(l2, sizeof(l2), "Out of range");
    }

    LCD_ShowLines("Intercept:", l2);
    HAL_Delay(CALIB_LCD_RESULT_DELAY);

    /* Display maximum linearity error */
    if (isfinite(session->summary.max_linearity_error_pct) &&
        session->summary.max_linearity_error_pct >= 0.0f &&
        session->summary.max_linearity_error_pct < 10000.0f)
    {
        snprintf(l2, sizeof(l2), "%.2f%%",
                 (double)session->summary.max_linearity_error_pct);
    }
    else
    {
        snprintf(l2, sizeof(l2), "Out of range");
    }

    LCD_ShowLines("Max linear err", l2);
    HAL_Delay(CALIB_LCD_RESULT_DELAY);

    /* Display average sensitivity */
    if (isfinite(session->summary.avg_sensitivity_mv_v_mm) &&
        fabsf(session->summary.avg_sensitivity_mv_v_mm) < 10000.0f)
    {
        snprintf(l2, sizeof(l2), "%.2f",
                 (double)session->summary.avg_sensitivity_mv_v_mm);
    }
    else
    {
        snprintf(l2, sizeof(l2), "Out of range");
    }

    LCD_ShowLines("Avg sensitivity", l2);
    HAL_Delay(CALIB_LCD_RESULT_DELAY);
}


/* =========================================================================
 * CalibTest_WriteCSV
 * ========================================================================= */
CalibResult_t CalibTest_WriteCSV(const CalibTestSession_t *session)
{
    FIL    fil;
    char   filename[20];
    char   row[160];
   // char    filename[24];

    CalibTest_BuildFilename(filename, sizeof(filename),
                            &session->timestamp);

    if (f_open(&fil, filename, FA_CREATE_ALWAYS | FA_WRITE) != FR_OK)
    {
        LCD_ShowLines("File Open Error", "Check SD card!");
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return CALIB_SD_ERROR;
    }

    /* --- Header --- */
    f_puts("Calibration Test Report\r\n", &fil);

    snprintf(row, sizeof(row), "Date,%02u/%02u/%02u\r\n",
             (unsigned)session->timestamp.dayofmonth,
             (unsigned)session->timestamp.month,
             (unsigned)session->timestamp.year);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Time,%02u:%02u:%02u\r\n",
             (unsigned)session->timestamp.hour,
             (unsigned)session->timestamp.minutes,
             (unsigned)session->timestamp.seconds);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Stroke Range (mm),%.3f\r\n",
             session->params.stroke_range_mm);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Excitation Voltage (V),%.4f\r\n",
             session->params.excitation_voltage_v);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Operational Displacement (mm),%.3f\r\n",
             session->params.operational_disp_mm);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Null Position (mm),%.4f\r\n",
             session->null_pos_mm);
    f_puts(row, &fil);

    f_puts("\r\n", &fil);

    /* --- Column headers --- */
    f_puts("Point,"
           "Displacement(mm),"
           "Output Voltage(V),"
           "Sensitivity(V/mm/V),"
           "Sensitivity(mV/V/mm),"
           "Linearity(%)\r\n", &fil);

    /* --- 11 data rows --- */
    for (uint8_t i = 0; i < session->points_collected; i++)
    {
        const CalibPoint_t *pt = &session->points[i];
        snprintf(row, sizeof(row),
                 "%u,%.4f,%.6f,%.6f,%.4f,%.4f\r\n",
                 (unsigned)(i + 1u),
                 pt->displacement_mm,
                 pt->output_voltage_v,
                 pt->sensitivity_v_mm_v,
                 pt->sensitivity_mv_v_mm,
                 pt->linearity_pct);
        f_puts(row, &fil);
    }

    f_puts("\r\n", &fil);

    /* --- Summary --- */
    f_puts("--- Summary ---\r\n", &fil);

    snprintf(row, sizeof(row), "Best-Fit Slope (V/mm),%.6f\r\n",
             session->summary.best_fit_slope);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Best-Fit Intercept (V),%.6f\r\n",
             session->summary.best_fit_intercept);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Max Linearity Error (%%),%.4f\r\n",
             session->summary.max_linearity_error_pct);
    f_puts(row, &fil);

    snprintf(row, sizeof(row), "Avg Sensitivity (mV/V/mm),%.4f\r\n",
             session->summary.avg_sensitivity_mv_v_mm);
    f_puts(row, &fil);

    f_close(&fil);

    LCD_ShowLines("CSV Saved:", filename);
    HAL_Delay(CALIB_LCD_RESULT_DELAY);

    return CALIB_OK;
}

/* =========================================================================
 * CalibTest_Run  —  Top-level entry point
 * ========================================================================= */
CalibResult_t CalibTest_Run(LinearAxis_t *axis,
                            float         pre_null_mm,
                            bool          null_is_valid)
{
    CalibTestSession_t session;
    memset(&session, 0, sizeof(session));
    CalibResult_t res;

    DS3231_GetTime(&session.timestamp);

    LCD_ShowLines("-CALIB TEST-", "Enter params...");
    HAL_Delay(CALIB_LCD_MSG_DELAY);

    res = CalibTest_EnterParams(&session);
    if (res != CALIB_OK)
    {
        LCD_ShowLines("Params aborted.", NULL);
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return res;
    }

    /* Null step — skip UI when already valid */
    if (null_is_valid == true)
    {
        LCD_ShowLines("Using saved", "NULL ref...");
        HAL_Delay(CALIB_LCD_MSG_DELAY);
    }
    else
    {
        LCD_ShowLines("Set NULL ref.", "Follow prompts");
        HAL_Delay(CALIB_LCD_MSG_DELAY);
    }

    res = CalibTest_SetNull(axis, &session, pre_null_mm, null_is_valid);
    if (res != CALIB_OK)
    {
        LCD_ShowLines("Null aborted.", NULL);
        HAL_Delay(CALIB_LCD_MSG_DELAY);
        return res;
    }

    /* Step 4: 11 points */
    for (uint8_t i = 0; i < CALIB_NUM_POINTS; )
    {
        res = CalibTest_CollectPoint(axis, &session, i);

        if (res == CALIB_ABORTED)
        {
            LCD_ShowLines("Test cancelled.", NULL);
            HAL_Delay(CALIB_LCD_MSG_DELAY);
            return CALIB_ABORTED;
        }
        if (res == CALIB_INPUT_ERROR)
        {
            /* Retry same point — do not increment i */
            continue;
        }
        if (res != CALIB_OK) return res;

        i++; /* advance only on success */
    }

    /* Step 5: Compute summary */
    CalibTest_ComputeSummary(&session);

    /* Step 6: Display summary */
    LCD_ShowLines("-- SUMMARY --", NULL);
    HAL_Delay(CALIB_LCD_MSG_DELAY);
    CalibTest_DisplaySummary(&session);

    /* Step 7: Write CSV */
    LCD_ShowLines("Saving CSV...", NULL);
    HAL_Delay(500);
    res = CalibTest_WriteCSV(&session);
    if (res != CALIB_OK) return res;

    /* Step 8: Return to null */
    LCD_ShowLines("Returning to", "null pos...");
    Axis_MoveAbsolute(axis, session.null_pos_mm);
    while (Axis_IsMoving(axis)) { __NOP(); }

    LCD_ShowLines("Calibration", "Complete!  :)");
    HAL_Delay(CALIB_LCD_RESULT_DELAY);

    return CALIB_OK;
}

