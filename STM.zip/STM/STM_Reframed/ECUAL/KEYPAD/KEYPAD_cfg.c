
#include "KEYPAD.h"

const KEYPAD_CfgType KEYPAD_CfgParam[KEYPAD_UNITS] =
{
	// KeyPAD Unit 1 Configurations
    {
    	/* ROWs Pins Info */
		{GPIOA, GPIOB, GPIOB, GPIOB},
		{GPIO_PIN_11, GPIO_PIN_12, GPIO_PIN_2, GPIO_PIN_1},
		/* COLs Pins */
	    {GPIOC, GPIOC, GPIOC, GPIOA},
		{GPIO_PIN_8, GPIO_PIN_6, GPIO_PIN_5, GPIO_PIN_12}
	}
};
