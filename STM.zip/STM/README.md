# STM
This is remote working director of Special Testing Machine's firmware
