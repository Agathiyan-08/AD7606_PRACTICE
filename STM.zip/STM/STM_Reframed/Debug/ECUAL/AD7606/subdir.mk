################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ECUAL/AD7606/ad7606.c 

OBJS += \
./ECUAL/AD7606/ad7606.o 

C_DEPS += \
./ECUAL/AD7606/ad7606.d 


# Each subdirectory must supply rules for building sources it contributes
ECUAL/AD7606/%.o ECUAL/AD7606/%.su ECUAL/AD7606/%.cyclo: ../ECUAL/AD7606/%.c ECUAL/AD7606/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../FATFS/Target -I../FATFS/App -I../Middlewares/Third_Party/FatFs/src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-ECUAL-2f-AD7606

clean-ECUAL-2f-AD7606:
	-$(RM) ./ECUAL/AD7606/ad7606.cyclo ./ECUAL/AD7606/ad7606.d ./ECUAL/AD7606/ad7606.o ./ECUAL/AD7606/ad7606.su

.PHONY: clean-ECUAL-2f-AD7606

