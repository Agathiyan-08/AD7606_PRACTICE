/*
 * AD76061.c
 *
 *  Created on: Oct 28, 2026
 *      Author: Lenovo
 */
#include "ad7606.h"

int16_t Reading_req[8];
float voltages[8];

void ADC_Reset(void)
{
    // Set the RESET pin high - ADC restarts
    HAL_GPIO_WritePin(ADC_RST_GPIO_Port, ADC_RST_Pin, GPIO_PIN_SET);
    HAL_Delay(1); // Minimum required is 50ns.

    HAL_GPIO_WritePin(ADC_RST_GPIO_Port, ADC_RST_Pin, GPIO_PIN_RESET); // Set reset to low
    HAL_Delay(5); // Settle time after reset
}

void ADC_Init(void)
{
    ADC_Reset();

    // Set the over-sampling ratio (000)
    HAL_GPIO_WritePin(ADC_OS0_GPIO_Port, ADC_OS0_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(ADC_OS1_GPIO_Port, ADC_OS1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(ADC_OS2_GPIO_Port, ADC_OS2_Pin, GPIO_PIN_RESET);

    // Set the range to +/- 10V by setting this pin to high
    HAL_GPIO_WritePin(ADC_Range_GPIO_Port, ADC_Range_Pin, GPIO_PIN_SET);

    // Set the Chip Select line HIGH
    HAL_GPIO_WritePin(ADC_CS_GPIO_Port, ADC_CS_Pin, GPIO_PIN_SET);

    // The AD7606 requires a High-to-Low falling edge to start conversion.
    HAL_GPIO_WritePin(ADC_CVA_GPIO_Port, ADC_CVA_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(ADC_CVB_GPIO_Port, ADC_CVB_Pin, GPIO_PIN_SET);

    HAL_Delay(10);
}

HAL_StatusTypeDef ADC_ReadData(int16_t *output_channels)
{

    HAL_GPIO_WritePin(ADC_CVA_GPIO_Port, ADC_CVA_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(ADC_CVB_GPIO_Port, ADC_CVB_Pin, GPIO_PIN_RESET);

    // Give a tiny hold time for the falling edge to register
    HAL_Delay(1);

    // Return conversion pins back to HIGH idle state
    HAL_GPIO_WritePin(ADC_CVA_GPIO_Port, ADC_CVA_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(ADC_CVB_GPIO_Port, ADC_CVB_Pin, GPIO_PIN_SET);

    // We only proceed when Busy drops back down to LOW (Conversion Complete).
    while(HAL_GPIO_ReadPin(ADC_Busy_GPIO_Port, ADC_Busy_Pin) == GPIO_PIN_SET)
    {

    }

    // Drop CS LOW to open the shift register SPI lines
    HAL_GPIO_WritePin(ADC_CS_GPIO_Port, ADC_CS_Pin, GPIO_PIN_RESET);

    HAL_SPI_Receive(&hspi3, (uint8_t*)output_channels, 8, HAL_MAX_DELAY);

    // Raise CS HIGH to close the communication window
    HAL_GPIO_WritePin(ADC_CS_GPIO_Port, ADC_CS_Pin, GPIO_PIN_SET);

    return HAL_OK;

}

// Conversion
void Volt_Conv(void)
{
    ADC_ReadData(Reading_req);

    if(ADC_ReadData(Reading_req) == HAL_OK)
    {
    	for(int i = 0; i < 8; i++)
    	    {
    	        voltages[i] = ((float)Reading_req[i] * (10.0f / 32768.0f));
    	    }
    }
}

// Connectivity test
uint8_t Is_ADC_Connected()
{
	if(ADC_ReadData(Reading_req) == !HAL_OK)
	{
		return 1;
	}
	return 0;
}
